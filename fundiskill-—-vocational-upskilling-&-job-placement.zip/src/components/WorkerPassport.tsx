import React, { useState } from 'react';
import { UserWorkerProfile } from '../types';
import { 
  Award, 
  Clock, 
  Database, 
  RefreshCw, 
  DownloadCloud, 
  MapPin, 
  Phone, 
  CheckCircle2, 
  User, 
  Share2,
  FileText,
  ShieldCheck
} from 'lucide-react';

interface WorkerPassportProps {
  profile: UserWorkerProfile;
  onUpdateProfile: (updated: Partial<UserWorkerProfile>) => void;
  onManualSync: () => void;
  isSyncing: boolean;
}

export const WorkerPassport: React.FC<WorkerPassportProps> = ({
  profile,
  onUpdateProfile,
  onManualSync,
  isSyncing,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(profile.name);
  const [editPhone, setEditPhone] = useState(profile.phone);
  const [editCity, setEditCity] = useState(profile.city);
  const [editTrade, setEditTrade] = useState(profile.tradeSpecialty);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      name: editName,
      phone: editPhone,
      city: editCity,
      tradeSpecialty: editTrade,
    });
    setIsEditing(false);
  };

  const handleExportCV = () => {
    window.print();
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Top Digital ID Card */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-700 relative overflow-hidden">
        {/* Holographic Watermark effect */}
        <div className="absolute -right-8 -bottom-8 w-48 h-48 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-700/80 pb-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-amber-500 flex items-center justify-center text-slate-950 font-black text-2xl shadow-md border-2 border-white">
              {profile.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono uppercase tracking-widest text-amber-400">
                  NATIONAL SKILLS PASSPORT
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono">
                  VERIFIED
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-0.5">
                {profile.name}
              </h2>
              <div className="flex items-center gap-3 text-xs text-slate-300 mt-1">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  {profile.city}, {profile.country}
                </span>
                <span>·</span>
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  {profile.phone}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={() => setIsEditing(!isEditing)}
            className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold rounded-xl border border-slate-600 transition-colors"
          >
            {isEditing ? 'Cancel Edit' : 'Edit Profile'}
          </button>
        </div>

        {/* Profile Edit Inline Form */}
        {isEditing && (
          <form onSubmit={handleSaveProfile} className="py-4 border-b border-slate-700 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">Full Legal Name</label>
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-600 text-white focus:outline-none"
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">WhatsApp / Phone</label>
              <input
                type="text"
                value={editPhone}
                onChange={(e) => setEditPhone(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-600 text-white focus:outline-none"
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">City / Region</label>
              <input
                type="text"
                value={editCity}
                onChange={(e) => setEditCity(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-600 text-white focus:outline-none"
              />
            </div>
            <div className="flex items-end">
              <button
                type="submit"
                className="w-full py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg transition-colors"
              >
                Save Updates
              </button>
            </div>
          </form>
        )}

        {/* Passport Metric Tallies */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-6 font-mono text-center">
          <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <div className="text-[10px] text-slate-400 uppercase">Earned Badges</div>
            <div className="text-xl sm:text-2xl font-black text-amber-400 mt-0.5">
              {profile.earnedCertificates.length}
            </div>
          </div>

          <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <div className="text-[10px] text-slate-400 uppercase">Lab Hours Logged</div>
            <div className="text-xl sm:text-2xl font-black text-sky-400 mt-0.5">
              {profile.toolHoursLogged}h
            </div>
          </div>

          <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <div className="text-[10px] text-slate-400 uppercase">Data Saved</div>
            <div className="text-xl sm:text-2xl font-black text-emerald-400 mt-0.5">
              {profile.dataSavedMb.toFixed(1)}MB
            </div>
          </div>

          <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <div className="text-[10px] text-slate-400 uppercase">Offline Packs</div>
            <div className="text-xl sm:text-2xl font-black text-white mt-0.5">
              {profile.downloadedTracks.length}
            </div>
          </div>
        </div>
      </div>

      {/* Offline Sync Engine & Low-Data Telemetry Card */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 border border-emerald-200">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900">
                Low-Data Local Cache & Sync Engine
              </div>
              <div className="text-xs text-slate-500">
                {profile.offlineSyncQueue.length === 0
                  ? 'All practical lab results and module checks are synchronized.'
                  : `${profile.offlineSyncQueue.length} offline assessment records queued for sync.`}
              </div>
            </div>
          </div>

          <button
            onClick={onManualSync}
            disabled={isSyncing || profile.offlineSyncQueue.length === 0}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors shrink-0 ${
              profile.offlineSyncQueue.length > 0
                ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                : 'bg-slate-100 text-slate-400 cursor-default'
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Syncing...' : 'Sync Queued Data'}</span>
          </button>
        </div>

        <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 flex items-center justify-between font-mono">
          <span>Vector Schematics Reduction:</span>
          <span className="text-emerald-700 font-bold">94% Bandwidth Saved</span>
        </div>
      </div>

      {/* Verified Trade Certifications in Passport */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>VERIFIED TRADE CREDENTIALS & LICENSES</span>
          </h3>
          <button
            onClick={handleExportCV}
            className="text-xs font-semibold text-slate-700 hover:text-slate-950 flex items-center gap-1.5"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Print 1-Page Field CV</span>
          </button>
        </div>

        {profile.earnedCertificates.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-500 border border-dashed border-slate-200 rounded-xl">
            No certificates earned yet. Complete a vocational track and practical lab to earn your certified trade credential!
          </div>
        ) : (
          <div className="space-y-3">
            {profile.earnedCertificates.map((cert) => (
              <div
                key={cert.id}
                className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                    <span className="font-mono text-slate-700 font-bold">{cert.id}</span>
                    <span>·</span>
                    <span>Issued {cert.issueDate}</span>
                  </div>
                  <div className="text-sm font-bold text-slate-900">{cert.trackTitle}</div>
                  <div className="text-xs text-slate-600 mt-0.5">
                    Lab Score: <span className="font-bold text-emerald-700">{cert.practicalScore}%</span> · Theory: <span className="font-bold">{cert.theoryScore}%</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs text-emerald-700 font-bold px-2.5 py-1 bg-emerald-100 rounded-lg">
                    ✓ Verified Active
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
