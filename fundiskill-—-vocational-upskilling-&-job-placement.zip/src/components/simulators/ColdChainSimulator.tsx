import React, { useState } from 'react';
import { 
  ShieldPlus, 
  RotateCcw, 
  CheckCircle2, 
  AlertTriangle, 
  Volume2, 
  VolumeX, 
  Wrench,
  Award,
  Thermometer
} from 'lucide-react';

interface ColdChainSimulatorProps {
  onCompleteLab?: (score: number) => void;
  lowDataMode?: boolean;
}

export const ColdChainSimulator: React.FC<ColdChainSimulatorProps> = ({ 
  onCompleteLab,
  lowDataMode = false 
}) => {
  const [gasketRepaired, setGasketRepaired] = useState(false);
  const [condenserCleaned, setCondenserCleaned] = useState(false);
  const [dollarBillTestPassed, setDollarBillTestPassed] = useState(false);
  const [labSubmitted, setLabSubmitted] = useState(false);
  const [audioExplaining, setAudioExplaining] = useState(false);

  // Temperature logic
  const currentTemp = gasketRepaired && condenserCleaned 
    ? 4.2 
    : (gasketRepaired || condenserCleaned ? 6.8 : 9.6);

  const isSafeZone = currentTemp >= 2.0 && currentTemp <= 8.0;

  const handleDollarBillTest = () => {
    if (gasketRepaired) {
      setDollarBillTestPassed(true);
    } else {
      setDollarBillTestPassed(false);
    }
  };

  const handleAudioGuide = () => {
    if ('speechSynthesis' in window) {
      if (audioExplaining) {
        window.speechSynthesis.cancel();
        setAudioExplaining(false);
        return;
      }
      setAudioExplaining(true);
      const msg = isSafeZone
        ? "Vaccine cold chain restored! Internal cabinet temperature is steady at 4.2 degrees Celsius, within WHO specifications. Vaccines are safe."
        : "Alert: Refrigerator temperature is at 9.6 degrees Celsius. Air leaks through the damaged door gasket and clogged condenser fins are causing compressor overheating.";
      
      const utterance = new SpeechSynthesisUtterance(msg);
      utterance.rate = 0.95;
      utterance.onend = () => setAudioExplaining(false);
      utterance.onerror = () => setAudioExplaining(false);
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleFinishLab = () => {
    setLabSubmitted(true);
    if (onCompleteLab) {
      onCompleteLab(isSafeZone ? 98 : 70);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-4">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-3 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-emerald-700 tracking-wide">PRACTICAL SIMULATOR</span>
            <span className="text-slate-300">·</span>
            <span className="text-xs text-slate-500">WHO PQS Standard E003</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Solar Direct-Drive Vaccine Cold-Chain Lab</h2>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleAudioGuide}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
          >
            {audioExplaining ? <VolumeX className="w-3.5 h-3.5 text-amber-600" /> : <Volume2 className="w-3.5 h-3.5" />}
            <span>{audioExplaining ? 'Stop Voice' : 'Voice Guide'}</span>
          </button>

          <button
            onClick={() => {
              setGasketRepaired(false);
              setCondenserCleaned(false);
              setDollarBillTestPassed(false);
              setLabSubmitted(false);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Refrigerator Digital Logger & Internal Temp Monitor */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-slate-900 text-slate-100 p-4 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between mb-3 text-xs">
              <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                <Thermometer className="w-4 h-4 text-emerald-400" />
                WHO PQS 30-DAY ELECTRONIC TEMPERATURE RECORDER
              </span>
              <span className={`px-2 py-0.5 rounded text-[11px] font-mono ${isSafeZone ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-red-950 text-red-400 border border-red-800 animate-pulse'}`}>
                {isSafeZone ? 'SAFE (+2°C to +8°C)' : 'CRITICAL WARM ALARM (> +8°C)'}
              </span>
            </div>

            {/* Big Temperature Gauge */}
            <div className="p-6 bg-slate-950 rounded-xl border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-6">
              <div className="text-center sm:text-left">
                <div className="text-xs text-slate-400 font-mono">CABINET INTERNAL TEMP</div>
                <div className={`text-5xl font-black font-mono tracking-tight mt-1 ${isSafeZone ? 'text-emerald-400' : 'text-red-400'}`}>
                  +{currentTemp.toFixed(1)}°C
                </div>
                <div className="text-xs text-slate-400 mt-1 font-mono">
                  TARGET SPEC: +2.0°C to +8.0°C
                </div>
              </div>

              {/* Status Graphic Visual */}
              <div className="w-48 bg-slate-900 p-3 rounded-lg border border-slate-800 text-xs space-y-2">
                <div className="flex justify-between items-center text-slate-300">
                  <span>Compressor RPM:</span>
                  <span className="font-mono text-emerald-400 font-bold">{condenserCleaned ? '2400 RPM' : '3600 RPM (HIGH LOAD)'}</span>
                </div>
                <div className="flex justify-between items-center text-slate-300">
                  <span>Door Seal:</span>
                  <span className={`font-mono font-bold ${gasketRepaired ? 'text-emerald-400' : 'text-red-400'}`}>
                    {gasketRepaired ? 'AIRTIGHT' : 'AIR LEAK'}
                  </span>
                </div>
                <div className="flex justify-between items-center text-slate-300">
                  <span>Solar Drive:</span>
                  <span className="font-mono text-amber-400 font-bold">145 W (PEAK SUN)</span>
                </div>
              </div>
            </div>

            {/* Test Simulation: Dollar-Bill Test */}
            <div className="mt-4 pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">
              <div>
                <span className="font-semibold text-slate-200">Gasket Compression Test:</span> Insert paper bill into door seal and pull.
              </div>
              <button
                onClick={handleDollarBillTest}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-medium transition-colors"
              >
                Perform Paper-Slip Pull Test
              </button>
            </div>

            {dollarBillTestPassed !== undefined && (
              <div className="mt-2 text-xs font-mono">
                {dollarBillTestPassed ? (
                  <span className="text-emerald-400 font-semibold">✓ Test Passed: Strong friction resistance felt. Gasket is airtight.</span>
                ) : (
                  <span className="text-amber-400 font-semibold">⚠ Test Failed: Paper slipped out freely with zero resistance. Gasket deformed.</span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right: Corrective Actions */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
              <Wrench className="w-3.5 h-3.5 text-emerald-600" />
              <span>COLD-CHAIN CORRECTIVE REPAIRS</span>
            </div>

            <button
              onClick={() => {
                setGasketRepaired(true);
                setDollarBillTestPassed(true);
              }}
              disabled={gasketRepaired}
              className={`w-full py-2.5 px-3 text-xs font-medium rounded-lg text-left transition-colors flex items-center justify-between ${
                gasketRepaired
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
              }`}
            >
              <div>
                <div className="font-semibold">1. Replace Magnetic Door Gasket</div>
                <div className="text-[10px] text-slate-500">Miter cut and seat airtight silicone gasket</div>
              </div>
              {gasketRepaired && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
            </button>

            <button
              onClick={() => setCondenserCleaned(true)}
              disabled={condenserCleaned}
              className={`w-full py-2.5 px-3 text-xs font-medium rounded-lg text-left transition-colors flex items-center justify-between ${
                condenserCleaned
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
              }`}
            >
              <div>
                <div className="font-semibold">2. Clean & Brush Condenser Fins</div>
                <div className="text-[10px] text-slate-500">Clear dust and lint to allow heat dissipation</div>
              </div>
              {condenserCleaned && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
            </button>

            {/* Assessment Completion */}
            <div className="pt-2">
              <button
                onClick={handleFinishLab}
                disabled={labSubmitted}
                className={`w-full py-2.5 px-4 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-all shadow-sm ${
                  isSafeZone
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    : 'bg-slate-900 hover:bg-slate-800 text-white'
                }`}
              >
                <Award className="w-4 h-4" />
                <span>{labSubmitted ? 'Practical Assessment Recorded!' : 'Submit Lab for Certification'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
