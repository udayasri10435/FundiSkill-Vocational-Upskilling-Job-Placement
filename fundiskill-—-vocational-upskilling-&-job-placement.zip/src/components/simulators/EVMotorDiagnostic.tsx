import React, { useState } from 'react';
import { 
  Zap, 
  RotateCcw, 
  CheckCircle2, 
  AlertTriangle, 
  Volume2, 
  VolumeX, 
  Wrench,
  Award,
  Gauge
} from 'lucide-react';

interface EVMotorDiagnosticProps {
  onCompleteLab?: (score: number) => void;
  lowDataMode?: boolean;
}

export const EVMotorDiagnostic: React.FC<EVMotorDiagnosticProps> = ({ 
  onCompleteLab,
  lowDataMode = false 
}) => {
  // Test states
  const [wheelRotationDeg, setWheelRotationDeg] = useState(0);
  const [throttlePercent, setThrottlePercent] = useState(0);
  const [cellBalancingActive, setCellBalancingActive] = useState(false);
  const [hallSensorReplaced, setHallSensorReplaced] = useState(false);
  const [labSubmitted, setLabSubmitted] = useState(false);
  const [audioExplaining, setAudioExplaining] = useState(false);

  // 16 Series Cell Voltages (Cell 11 is weak initially at 2.72V)
  const [cells, setCells] = useState<number[]>([
    3.32, 3.31, 3.33, 3.32, 3.30, 3.32, 3.31, 3.33,
    3.32, 3.31, 2.74, 3.32, 3.30, 3.33, 3.31, 3.32
  ]);

  // Compute Hall sensor states based on wheel rotation angle
  // Hall A fails if not replaced
  const angleNorm = (wheelRotationDeg % 360);
  const hallA_val = hallSensorReplaced 
    ? (angleNorm >= 0 && angleNorm < 180 ? 5.0 : 0.0) 
    : 0.0; // Defective Hall sensor stays stuck at 0V
  const hallB_val = (angleNorm >= 60 && angleNorm < 240 ? 5.0 : 0.0);
  const hallC_val = (angleNorm >= 120 && angleNorm < 300 ? 5.0 : 0.0);

  // Throttle potentiometer voltage: 0.85V to 4.25V
  const throttleVoltage = (0.85 + (throttlePercent / 100) * (4.25 - 0.85)).toFixed(2);

  // Minimum cell voltage and Delta-V
  const minCell = Math.min(...cells);
  const maxCell = Math.max(...cells);
  const deltaV = (maxCell - minCell).toFixed(2);

  // Balance cells
  const handleBalancePack = () => {
    setCellBalancingActive(true);
    setTimeout(() => {
      setCells(prev => prev.map(() => 3.32));
      setCellBalancingActive(false);
    }, 1200);
  };

  const isBmsHealthy = Number(deltaV) <= 0.05;
  const isMotorCommutating = hallSensorReplaced;
  const isOverallResolved = isBmsHealthy && isMotorCommutating;

  const handleAudioGuide = () => {
    if ('speechSynthesis' in window) {
      if (audioExplaining) {
        window.speechSynthesis.cancel();
        setAudioExplaining(false);
        return;
      }
      setAudioExplaining(true);
      const msg = isOverallResolved
        ? "Excellent EV repair! The battery pack delta is under 20 millivolts, and all three motor hall sensors are pulsing cleanly from 0 to 5 volts. Motor is ready for road test."
        : `Diagnostic update: Battery pack has an undervoltage delta of ${deltaV} volts on cell 11, and Hall Sensor A is stuck at 0 volts. Balance the pack and replace the stator sensor.`;
      
      const utterance = new SpeechSynthesisUtterance(msg);
      utterance.rate = 0.95;
      utterance.onend = () => setAudioExplaining(false);
      utterance.onerror = () => setAudioExplaining(false);
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleFinishLab = () => {
    setLabSubmitted(true);
    if (onCompleteLab) {
      onCompleteLab(isOverallResolved ? 98 : 75);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-4">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-3 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-amber-700 tracking-wide">PRACTICAL SIMULATOR</span>
            <span className="text-slate-300">·</span>
            <span className="text-xs text-slate-500">E-Mobility Fleet Lab</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Electric 2-Wheeler (Boda) Battery & Motor Lab</h2>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleAudioGuide}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
          >
            {audioExplaining ? <VolumeX className="w-3.5 h-3.5 text-amber-600" /> : <Volume2 className="w-3.5 h-3.5" />}
            <span>{audioExplaining ? 'Stop Voice' : 'Voice Guide'}</span>
          </button>

          <button
            onClick={() => {
              setCells([3.32, 3.31, 3.33, 3.32, 3.30, 3.32, 3.31, 3.33, 3.32, 3.31, 2.74, 3.32, 3.30, 3.33, 3.31, 3.32]);
              setHallSensorReplaced(false);
              setWheelRotationDeg(0);
              setThrottlePercent(0);
              setLabSubmitted(false);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Battery Pack Cell Matrix & Wheel Rotation Bench */}
        <div className="lg:col-span-8 space-y-4">
          {/* Sub-Section 1: 48V/72V LiFePO4 Cell Voltage Telemetry */}
          <div className="bg-slate-900 text-slate-100 p-4 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between mb-3 text-xs">
              <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-amber-400" />
                BMS TELEMETRY: 16-CELL SERIES VOLTAGE MAP
              </span>
              <span className={`px-2 py-0.5 rounded text-[11px] font-mono ${isBmsHealthy ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-red-950 text-red-400 border border-red-800'}`}>
                DELTA-V: {deltaV}V ({isBmsHealthy ? 'BALANCED' : 'IMBALANCE CRITICAL'})
              </span>
            </div>

            <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5 text-center font-mono">
              {cells.map((volts, idx) => {
                const isWeak = volts < 3.0;
                return (
                  <div
                    key={idx}
                    className={`p-1.5 rounded-lg border text-xs transition-colors ${
                      isWeak
                        ? 'bg-red-950/80 border-red-500 text-red-200 animate-pulse'
                        : 'bg-slate-950 border-slate-800 text-slate-200'
                    }`}
                  >
                    <div className="text-[10px] text-slate-400">C{idx + 1}</div>
                    <div className="font-bold">{volts.toFixed(2)}V</div>
                  </div>
                );
              })}
            </div>

            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800 text-xs">
              <div className="text-slate-400">
                Pack Total: <span className="text-amber-300 font-bold font-mono">{(cells.reduce((a, b) => a + b, 0)).toFixed(1)}V DC</span>
              </div>
              <button
                onClick={handleBalancePack}
                disabled={isBmsHealthy || cellBalancingActive}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  isBmsHealthy
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    : 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold'
                }`}
              >
                {cellBalancingActive ? 'Balancing Cells...' : 'Initiate Active BMS Cell Balancing'}
              </button>
            </div>
          </div>

          {/* Sub-Section 2: BLDC Hub Motor & Hall Effect Commutation Stage */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                <Gauge className="w-4 h-4 text-sky-600" />
                BLDC HUB MOTOR COMMUTATION TEST BENCH
              </span>
              <span className="text-slate-500">120° Hall Sensor Array</span>
            </div>

            {/* Wheel & Sensor Visual Canvas */}
            <div className="flex flex-col sm:flex-row items-center gap-6 p-4 bg-slate-50 rounded-xl border border-slate-200">
              {/* Interactive Rotating Wheel Canvas */}
              <div className="relative w-36 h-36 flex items-center justify-center">
                <div 
                  className="w-32 h-32 rounded-full border-4 border-slate-800 bg-slate-200 relative flex items-center justify-center transition-transform duration-75 shadow-inner"
                  style={{ transform: `rotate(${wheelRotationDeg}deg)` }}
                >
                  <div className="w-12 h-12 rounded-full bg-slate-700 border-2 border-slate-500" />
                  {/* Spokes */}
                  <div className="absolute w-full h-0.5 bg-slate-400" />
                  <div className="absolute h-full w-0.5 bg-slate-400" />
                  {/* Magnet position marker */}
                  <div className="absolute top-1 w-3 h-3 rounded-full bg-amber-500 ring-2 ring-white" />
                </div>
              </div>

              {/* Controls and Sensor Signal Readouts */}
              <div className="flex-1 space-y-3 w-full">
                <div>
                  <div className="flex justify-between text-xs font-medium text-slate-700 mb-1">
                    <span>Rotate Rear Wheel Manually:</span>
                    <span className="font-mono">{wheelRotationDeg}°</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="720"
                    value={wheelRotationDeg}
                    onChange={(e) => setWheelRotationDeg(Number(e.target.value))}
                    className="w-full accent-slate-900 cursor-pointer"
                  />
                </div>

                {/* 3 Hall Sensor Signal indicators */}
                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <div className={`p-2 rounded-lg border font-mono ${hallA_val > 2 ? 'bg-emerald-50 border-emerald-400 text-emerald-900' : 'bg-slate-100 border-slate-200 text-slate-600'}`}>
                    <div className="text-[10px] text-slate-500">HALL A (U)</div>
                    <div className="font-bold text-sm">{hallA_val.toFixed(1)}V</div>
                    {!hallSensorReplaced && <div className="text-[9px] text-red-600 font-semibold">STUCK 0V</div>}
                  </div>

                  <div className={`p-2 rounded-lg border font-mono ${hallB_val > 2 ? 'bg-emerald-50 border-emerald-400 text-emerald-900' : 'bg-slate-100 border-slate-200 text-slate-600'}`}>
                    <div className="text-[10px] text-slate-500">HALL B (V)</div>
                    <div className="font-bold text-sm">{hallB_val.toFixed(1)}V</div>
                    <div className="text-[9px] text-emerald-600">PULSING</div>
                  </div>

                  <div className={`p-2 rounded-lg border font-mono ${hallC_val > 2 ? 'bg-emerald-50 border-emerald-400 text-emerald-900' : 'bg-slate-100 border-slate-200 text-slate-600'}`}>
                    <div className="text-[10px] text-slate-500">HALL C (W)</div>
                    <div className="font-bold text-sm">{hallC_val.toFixed(1)}V</div>
                    <div className="text-[9px] text-emerald-600">PULSING</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Throttle Sensor & Repair Toolbox */}
        <div className="lg:col-span-4 space-y-4">
          {/* Throttle Potentiometer Diagnostic */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="text-xs font-bold text-slate-800">THROTTLE POTENTIOMETER SWEEP</div>
            <div>
              <div className="flex justify-between text-xs text-slate-600 mb-1">
                <span>Twist Grip Throttle:</span>
                <span className="font-mono font-bold">{throttlePercent}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={throttlePercent}
                onChange={(e) => setThrottlePercent(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-xs flex items-center justify-between font-mono">
              <span className="text-slate-600">ECU Throttle Pin:</span>
              <span className="font-bold text-slate-900 text-sm">{throttleVoltage} V DC</span>
            </div>
            <div className="text-[11px] text-slate-500">
              Expected range: 0.8V (idle) to 4.2V (WOT). Linear voltage curve verified.
            </div>
          </div>

          {/* Corrective Action Box */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
              <Wrench className="w-3.5 h-3.5 text-amber-600" />
              <span>TECHNICIAN FIELD REPAIRS</span>
            </div>

            <button
              onClick={() => setHallSensorReplaced(true)}
              disabled={hallSensorReplaced}
              className={`w-full py-2.5 px-3 text-xs font-medium rounded-lg text-left transition-colors flex items-center justify-between ${
                hallSensorReplaced
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
              }`}
            >
              <div>
                <div className="font-semibold">Replace Hall Sensor A (41F Bi-Polar)</div>
                <div className="text-[10px] text-slate-500">Solder new 5V Hall switch inside motor hub</div>
              </div>
              {hallSensorReplaced && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
            </button>

            {/* Assessment Completion */}
            <div className="pt-2">
              <button
                onClick={handleFinishLab}
                disabled={labSubmitted}
                className={`w-full py-2.5 px-4 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-all shadow-sm ${
                  isOverallResolved
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    : 'bg-slate-900 hover:bg-slate-800 text-white'
                }`}
              >
                <Award className="w-4 h-4" />
                <span>{labSubmitted ? 'Practical Assessment Recorded!' : 'Submit Lab for Certification'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
