import React, { useState } from 'react';
import { 
  Sun, 
  Zap, 
  RotateCcw, 
  CheckCircle2, 
  AlertTriangle, 
  Volume2, 
  VolumeX, 
  Wrench,
  Award,
  HelpCircle
} from 'lucide-react';

interface SolarTroubleshooterProps {
  onCompleteLab?: (score: number) => void;
  lowDataMode?: boolean;
}

type TestPoint = 'tp_pv' | 'tp_inv_in' | 'tp_fuse' | 'tp_ground' | 'tp_battery' | 'tp_ac_out';
type MeterMode = 'DCV' | 'ACV' | 'OHM' | 'CONT';
type FaultId = 'blown_fuse' | 'loose_mc4' | 'ground_fault' | 'nominal';

export const SolarTroubleshooter: React.FC<SolarTroubleshooterProps> = ({ 
  onCompleteLab,
  lowDataMode = false 
}) => {
  const [activeFault, setActiveFault] = useState<FaultId>('blown_fuse');
  const [selectedProbe, setSelectedProbe] = useState<TestPoint>('tp_pv');
  const [meterMode, setMeterMode] = useState<MeterMode>('DCV');
  const [fixedActions, setFixedActions] = useState<string[]>([]);
  const [diagnosticLog, setDiagnosticLog] = useState<string[]>([
    'Multimeter initialized (CAT III 1000V calibrated).',
    'Customer report: Solar inverter displaying error red light, no power to health clinic refrigerator.'
  ]);
  const [labSubmitted, setLabSubmitted] = useState(false);
  const [audioExplaining, setAudioExplaining] = useState(false);

  // Compute realistic voltage readings based on fault and probe location
  const getMeterReading = (tp: TestPoint, mode: MeterMode): { value: string; unit: string; state: 'ok' | 'fault' | 'warn' } => {
    if (mode === 'ACV') {
      if (tp === 'tp_ac_out') {
        const isResolved = activeFault === 'nominal' || (activeFault === 'blown_fuse' && fixedActions.includes('fuse')) || (activeFault === 'loose_mc4' && fixedActions.includes('mc4'));
        return isResolved 
          ? { value: '230.4', unit: 'V AC', state: 'ok' }
          : { value: '000.0', unit: 'V AC', state: 'fault' };
      }
      return { value: '000.2', unit: 'V AC', state: 'warn' };
    }

    if (mode === 'OHM') {
      if (tp === 'tp_fuse') {
        if (activeFault === 'blown_fuse' && !fixedActions.includes('fuse')) {
          return { value: 'O.L', unit: 'MΩ (Open)', state: 'fault' };
        }
        return { value: '00.4', unit: 'Ω (Good)', state: 'ok' };
      }
      return { value: '1.24', unit: 'kΩ', state: 'ok' };
    }

    if (mode === 'CONT') {
      if (tp === 'tp_fuse') {
        if (activeFault === 'blown_fuse' && !fixedActions.includes('fuse')) {
          return { value: 'OPEN', unit: 'No Beep', state: 'fault' };
        }
        return { value: 'BEEP', unit: 'Closed Loop', state: 'ok' };
      }
      return { value: '---', unit: '', state: 'ok' };
    }

    // Default: DCV
    switch (tp) {
      case 'tp_pv':
        if (activeFault === 'loose_mc4' && !fixedActions.includes('mc4')) {
          return { value: '00.0', unit: 'V DC', state: 'fault' };
        }
        return { value: '82.6', unit: 'V DC', state: 'ok' };

      case 'tp_inv_in':
        if (activeFault === 'loose_mc4' && !fixedActions.includes('mc4')) {
          return { value: '00.0', unit: 'V DC', state: 'fault' };
        }
        return { value: '82.4', unit: 'V DC', state: 'ok' };

      case 'tp_fuse':
        if (activeFault === 'blown_fuse' && !fixedActions.includes('fuse')) {
          return { value: '82.4', unit: 'V Drop (Blown)', state: 'fault' };
        }
        return { value: '00.0', unit: 'V Drop', state: 'ok' };

      case 'tp_ground':
        if (activeFault === 'ground_fault' && !fixedActions.includes('ground')) {
          return { value: '46.8', unit: 'V DC (Leakage!)', state: 'fault' };
        }
        return { value: '00.1', unit: 'V DC', state: 'ok' };

      case 'tp_battery':
        return { value: '51.2', unit: 'V DC', state: 'ok' };

      case 'tp_ac_out':
        return { value: '00.0', unit: 'V DC (Switch to AC)', state: 'warn' };

      default:
        return { value: '00.0', unit: 'V DC', state: 'ok' };
    }
  };

  const currentReading = getMeterReading(selectedProbe, meterMode);

  // Probe testing handler
  const handleTestPoint = (tp: TestPoint, label: string) => {
    setSelectedProbe(tp);
    const reading = getMeterReading(tp, meterMode);
    setDiagnosticLog(prev => [
      `Probed ${label}: Read ${reading.value} ${reading.unit}`,
      ...prev.slice(0, 5)
    ]);
  };

  // Perform Repair Actions
  const handleRepairAction = (actionKey: string, actionName: string) => {
    if (!fixedActions.includes(actionKey)) {
      const next = [...fixedActions, actionKey];
      setFixedActions(next);
      setDiagnosticLog(prev => [
        `Executed Action: ${actionName}. Retesting system...`,
        ...prev.slice(0, 5)
      ]);
    }
  };

  // Check if system is successfully resolved
  const isResolved = 
    (activeFault === 'blown_fuse' && fixedActions.includes('fuse')) ||
    (activeFault === 'loose_mc4' && fixedActions.includes('mc4')) ||
    (activeFault === 'ground_fault' && fixedActions.includes('ground')) ||
    activeFault === 'nominal';

  // Voice narration of diagnostic feedback
  const handleAudioGuide = () => {
    if ('speechSynthesis' in window) {
      if (audioExplaining) {
        window.speechSynthesis.cancel();
        setAudioExplaining(false);
        return;
      }
      setAudioExplaining(true);
      const text = isResolved 
        ? "Excellent work technician! The DC circuit is restored. AC output is a steady 230 volts. Inverter status is now green and nominal."
        : `Diagnostic prompt: Currently diagnosing ${activeFault.replace('_', ' ')}. Check voltage drop across test points to locate the open circuit.`;
      
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.onend = () => setAudioExplaining(false);
      utterance.onerror = () => setAudioExplaining(false);
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleFinishLab = () => {
    setLabSubmitted(true);
    if (onCompleteLab) {
      onCompleteLab(isResolved ? 98 : 72);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-4">
      {/* Top Bar for Simulator */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-3 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-amber-700 tracking-wide">PRACTICAL SIMULATOR</span>
            <span className="text-slate-300">·</span>
            <span className="text-xs text-slate-500">Low-Data Vector Engine</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Solar PV Inverter & Wiring Diagnostics</h2>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleAudioGuide}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
            title="Listen to technician voice instructions"
          >
            {audioExplaining ? <VolumeX className="w-3.5 h-3.5 text-amber-600" /> : <Volume2 className="w-3.5 h-3.5" />}
            <span>{audioExplaining ? 'Stop Voice' : 'Voice Guide'}</span>
          </button>

          <button
            onClick={() => {
              setFixedActions([]);
              setLabSubmitted(false);
              setDiagnosticLog(['Resetting simulator test bench.']);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* Scenario Selector */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
        <div className="text-xs font-semibold text-slate-500 mb-2">SELECT FIELD FAULT SCENARIO:</div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          <button
            onClick={() => {
              setActiveFault('blown_fuse');
              setFixedActions([]);
              setLabSubmitted(false);
            }}
            className={`p-2.5 text-left rounded-lg border transition-all text-xs ${
              activeFault === 'blown_fuse'
                ? 'border-amber-500 bg-amber-50/60 text-amber-950 font-medium ring-1 ring-amber-400'
                : 'border-slate-200 hover:border-slate-300 text-slate-700'
            }`}
          >
            <div className="font-semibold">Case A: Blown DC Inverter Fuse</div>
            <div className="text-slate-500 text-[11px] mt-0.5">High DC surge during thunderstorm. Inverter dead.</div>
          </button>

          <button
            onClick={() => {
              setActiveFault('loose_mc4');
              setFixedActions([]);
              setLabSubmitted(false);
            }}
            className={`p-2.5 text-left rounded-lg border transition-all text-xs ${
              activeFault === 'loose_mc4'
                ? 'border-amber-500 bg-amber-50/60 text-amber-950 font-medium ring-1 ring-amber-400'
                : 'border-slate-200 hover:border-slate-300 text-slate-700'
            }`}
          >
            <div className="font-semibold">Case B: Loose MC4 Connector</div>
            <div className="text-slate-500 text-[11px] mt-0.5">Rooftop cable pulled by wind. Zero PV input.</div>
          </button>

          <button
            onClick={() => {
              setActiveFault('ground_fault');
              setFixedActions([]);
              setLabSubmitted(false);
            }}
            className={`p-2.5 text-left rounded-lg border transition-all text-xs ${
              activeFault === 'ground_fault'
                ? 'border-amber-500 bg-amber-50/60 text-amber-950 font-medium ring-1 ring-amber-400'
                : 'border-slate-200 hover:border-slate-300 text-slate-700'
            }`}
          >
            <div className="font-semibold">Case C: Wet Conduit Ground Fault</div>
            <div className="text-slate-500 text-[11px] mt-0.5">Monsoon water ingress causing F12 isolation error.</div>
          </button>
        </div>
      </div>

      {/* Main Two-Zone Simulator Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Interactive Circuit Schematic Diagram (Vector SVG) */}
        <div className="lg:col-span-8 bg-slate-900 text-slate-100 p-4 rounded-2xl relative overflow-hidden border border-slate-800">
          <div className="flex items-center justify-between mb-3 text-xs">
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${isResolved ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
              <span className="font-mono text-slate-300">
                STATUS: {isResolved ? 'NOMINAL · 230V AC ONLINE' : 'FAULT DETECTED · INSPECTION REQUIRED'}
              </span>
            </div>
            <span className="text-[11px] text-slate-400">Tap test points (TP) to measure</span>
          </div>

          {/* SVG Vector Schematic */}
          <div className="relative w-full aspect-[16/10] bg-slate-950 rounded-xl p-2 border border-slate-800 flex items-center justify-center">
            <svg viewBox="0 0 700 400" className="w-full h-full select-none">
              <defs>
                <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(255,255,255,0.03)" strokeWidth="1" />
                </pattern>
                <linearGradient id="pvGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#1e3a8a" />
                  <stop offset="100%" stopColor="#0f172a" />
                </linearGradient>
              </defs>

              <rect width="700" height="400" fill="url(#grid)" />

              {/* Wire lines */}
              {/* PV to Inverter DC+ (Red) */}
              <path 
                d="M 170 140 L 260 140 L 260 160 L 320 160" 
                fill="none" 
                stroke="#ef4444" 
                strokeWidth="4" 
                strokeDasharray={isResolved ? "none" : "6,4"}
              />
              {/* PV to Inverter DC- (Black) */}
              <path 
                d="M 170 200 L 260 200 L 260 220 L 320 220" 
                fill="none" 
                stroke="#38bdf8" 
                strokeWidth="4" 
              />

              {/* Inverter to AC Load (Orange/Cyan) */}
              <path 
                d="M 460 190 L 550 190" 
                fill="none" 
                stroke={isResolved ? "#10b981" : "#64748b"} 
                strokeWidth="4" 
              />

              {/* Battery Connection */}
              <path 
                d="M 390 270 L 390 310" 
                fill="none" 
                stroke="#f59e0b" 
                strokeWidth="3" 
              />

              {/* Ground Wire */}
              <path 
                d="M 350 270 L 350 350 L 320 350" 
                fill="none" 
                stroke="#22c55e" 
                strokeWidth="3" 
                strokeDasharray="4,4"
              />

              {/* Solar Array Component */}
              <g transform="translate(40, 100)">
                <rect width="130" height="130" rx="8" fill="url(#pvGrad)" stroke="#3b82f6" strokeWidth="2" />
                <line x1="20" y1="45" x2="110" y2="45" stroke="#60a5fa" strokeWidth="1" />
                <line x1="20" y1="85" x2="110" y2="85" stroke="#60a5fa" strokeWidth="1" />
                <line x1="65" y1="15" x2="65" y2="115" stroke="#60a5fa" strokeWidth="1" />
                <text x="65" y="148" textAnchor="middle" fill="#93c5fd" fontSize="12" fontWeight="bold">ROOFTOP PV (2x400W)</text>
                <text x="65" y="162" textAnchor="middle" fill="#64748b" fontSize="10">Voc: 84V · Imp: 9.8A</text>
              </g>

              {/* Hybrid Inverter Component */}
              <g transform="translate(320, 110)">
                <rect width="140" height="160" rx="10" fill="#1e293b" stroke={isResolved ? "#10b981" : "#f59e0b"} strokeWidth="2" />
                <text x="70" y="30" textAnchor="middle" fill="#f8fafc" fontSize="13" fontWeight="bold">MPPT INVERTER</text>
                
                {/* Fuse indicator inside inverter */}
                <rect x="25" y="45" width="40" height="18" rx="4" fill={fixedActions.includes('fuse') || activeFault !== 'blown_fuse' ? "#065f46" : "#7f1d1d"} stroke="#cbd5e1" strokeWidth="1" />
                <text x="45" y="58" textAnchor="middle" fill="#fff" fontSize="9" fontWeight="bold">
                  {fixedActions.includes('fuse') || activeFault !== 'blown_fuse' ? 'FUSE OK' : 'BLOWN'}
                </text>

                {/* LCD Display on Inverter */}
                <rect x="25" y="75" width="90" height="40" rx="4" fill="#022c22" stroke="#059669" strokeWidth="1" />
                <text x="70" y="94" textAnchor="middle" fill="#34d399" fontSize="11" fontFamily="monospace">
                  {isResolved ? '230V AC 50Hz' : (activeFault === 'blown_fuse' ? 'ERR: F04' : (activeFault === 'ground_fault' ? 'ERR: F12' : 'NO DC IN'))}
                </text>
                <text x="70" y="108" textAnchor="middle" fill="#6ee7b7" fontSize="9" fontFamily="monospace">
                  {isResolved ? 'PWR: 1150W' : 'STANDBY'}
                </text>
              </g>

              {/* Battery Pack */}
              <g transform="translate(340, 310)">
                <rect width="100" height="55" rx="6" fill="#1e293b" stroke="#f59e0b" strokeWidth="1.5" />
                <text x="50" y="24" textAnchor="middle" fill="#fef3c7" fontSize="10" fontWeight="bold">48V LiFePO4</text>
                <text x="50" y="40" textAnchor="middle" fill="#94a3b8" fontSize="9">SOC: 85%</text>
              </g>

              {/* AC Load (Clinic Refrigerator) */}
              <g transform="translate(550, 130)">
                <rect width="110" height="120" rx="8" fill="#1e293b" stroke="#38bdf8" strokeWidth="1.5" />
                <text x="55" y="35" textAnchor="middle" fill="#e0f2fe" fontSize="11" fontWeight="bold">CLINIC LOAD</text>
                <text x="55" y="55" textAnchor="middle" fill="#bae6fd" fontSize="9">Vaccine Fridge</text>
                <circle cx="55" cy="85" r="14" fill={isResolved ? "#059669" : "#64748b"} />
                <text x="55" y="89" textAnchor="middle" fill="#fff" fontSize="11">⚡</text>
              </g>

              {/* INTERACTIVE TEST POINT TARGETS */}
              {/* TP1: PV Output */}
              <g 
                onClick={() => handleTestPoint('tp_pv', 'TP1 (PV Strings)')}
                className="cursor-pointer group"
                transform="translate(190, 125)"
              >
                <circle cx="15" cy="15" r="16" fill={selectedProbe === 'tp_pv' ? "#e11d48" : "#fbbf24"} opacity="0.9" />
                <circle cx="15" cy="15" r="7" fill="#fff" />
                <text x="15" y="44" textAnchor="middle" fill="#fbbf24" fontSize="11" fontWeight="bold">TP1: PV</text>
              </g>

              {/* TP2: Inverter Input */}
              <g 
                onClick={() => handleTestPoint('tp_inv_in', 'TP2 (Inverter DC In)')}
                className="cursor-pointer group"
                transform="translate(270, 145)"
              >
                <circle cx="15" cy="15" r="16" fill={selectedProbe === 'tp_inv_in' ? "#e11d48" : "#fbbf24"} opacity="0.9" />
                <circle cx="15" cy="15" r="7" fill="#fff" />
                <text x="15" y="44" textAnchor="middle" fill="#fbbf24" fontSize="11" fontWeight="bold">TP2: DC IN</text>
              </g>

              {/* TP3: Inverter Fuse */}
              <g 
                onClick={() => handleTestPoint('tp_fuse', 'TP3 (Internal DC Fuse)')}
                className="cursor-pointer group"
                transform="translate(385, 145)"
              >
                <circle cx="15" cy="15" r="16" fill={selectedProbe === 'tp_fuse' ? "#e11d48" : "#fbbf24"} opacity="0.9" />
                <circle cx="15" cy="15" r="7" fill="#fff" />
                <text x="15" y="44" textAnchor="middle" fill="#fbbf24" fontSize="11" fontWeight="bold">TP3: FUSE</text>
              </g>

              {/* TP4: Ground Rod */}
              <g 
                onClick={() => handleTestPoint('tp_ground', 'TP4 (Earthing Rod)')}
                className="cursor-pointer group"
                transform="translate(290, 335)"
              >
                <circle cx="15" cy="15" r="14" fill={selectedProbe === 'tp_ground' ? "#e11d48" : "#fbbf24"} opacity="0.9" />
                <circle cx="15" cy="15" r="6" fill="#fff" />
                <text x="15" y="38" textAnchor="middle" fill="#fbbf24" fontSize="11" fontWeight="bold">TP4: GND</text>
              </g>

              {/* TP6: AC Output */}
              <g 
                onClick={() => handleTestPoint('tp_ac_out', 'TP6 (Inverter AC Output)')}
                className="cursor-pointer group"
                transform="translate(490, 175)"
              >
                <circle cx="15" cy="15" r="16" fill={selectedProbe === 'tp_ac_out' ? "#e11d48" : "#fbbf24"} opacity="0.9" />
                <circle cx="15" cy="15" r="7" fill="#fff" />
                <text x="15" y="44" textAnchor="middle" fill="#fbbf24" fontSize="11" fontWeight="bold">TP6: AC OUT</text>
              </g>
            </svg>
          </div>

          {/* Diagnostic Event Log */}
          <div className="mt-3 bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-xs font-mono space-y-1">
            <div className="text-slate-400 font-sans text-[11px] font-semibold">TECHNICIAN FIELD LOG:</div>
            {diagnosticLog.slice(0, 3).map((log, idx) => (
              <div key={idx} className="text-slate-300 truncate">
                <span className="text-amber-400">›</span> {log}
              </div>
            ))}
          </div>
        </div>

        {/* Right: Digital Multimeter Instrument & Corrective Actions */}
        <div className="lg:col-span-4 space-y-4">
          {/* Digital Multimeter Panel */}
          <div className="bg-amber-500 p-3.5 rounded-2xl shadow-md border-2 border-amber-600">
            {/* Multimeter Top Brand */}
            <div className="flex items-center justify-between text-slate-900 font-bold text-xs tracking-wider mb-2">
              <span>FUNDI-METER 87V</span>
              <span className="text-[10px] bg-slate-900 text-white px-2 py-0.5 rounded">CAT III 1000V</span>
            </div>

            {/* LCD Screen */}
            <div className="bg-[#a3b18a] p-3 rounded-lg border-2 border-slate-700 shadow-inner font-mono text-slate-900 mb-3">
              <div className="flex justify-between items-center text-[10px] text-slate-800 font-bold mb-1">
                <span>HOLD AUTO</span>
                <span>{meterMode}</span>
              </div>
              <div className="text-3xl font-extrabold tracking-tight text-right py-1">
                {currentReading.value}
              </div>
              <div className="text-right text-xs font-bold text-slate-800">
                {currentReading.unit}
              </div>
            </div>

            {/* Rotary Selector Switch */}
            <div className="bg-slate-900 p-2 rounded-xl text-white mb-3">
              <div className="text-[10px] text-slate-400 font-medium text-center mb-1.5">ROTARY DIAL SETTING</div>
              <div className="grid grid-cols-4 gap-1">
                <button
                  onClick={() => setMeterMode('DCV')}
                  className={`py-1.5 text-xs font-mono font-bold rounded transition-colors ${
                    meterMode === 'DCV' ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  ⎓ V
                </button>
                <button
                  onClick={() => setMeterMode('ACV')}
                  className={`py-1.5 text-xs font-mono font-bold rounded transition-colors ${
                    meterMode === 'ACV' ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  ~ V
                </button>
                <button
                  onClick={() => setMeterMode('OHM')}
                  className={`py-1.5 text-xs font-mono font-bold rounded transition-colors ${
                    meterMode === 'OHM' ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Ω
                </button>
                <button
                  onClick={() => setMeterMode('CONT')}
                  className={`py-1.5 text-xs font-mono font-bold rounded transition-colors ${
                    meterMode === 'CONT' ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  🔊
                </button>
              </div>
            </div>

            {/* Current Probe Target Indicator */}
            <div className="bg-amber-600/40 p-2 rounded-lg text-slate-950 text-xs">
              <span className="font-semibold">Red Probe at:</span> {selectedProbe.toUpperCase()}
              <div className="text-[11px] text-slate-800 mt-0.5">
                {selectedProbe === 'tp_pv' && 'Solar string Voc output'}
                {selectedProbe === 'tp_inv_in' && 'Inverter DC terminal'}
                {selectedProbe === 'tp_fuse' && 'Inverter internal ceramic fuse'}
                {selectedProbe === 'tp_ground' && 'Grounding rod & metallic conduit'}
                {selectedProbe === 'tp_ac_out' && '230V AC output to load'}
              </div>
            </div>
          </div>

          {/* Corrective Field Repairs Box */}
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
              <Wrench className="w-3.5 h-3.5 text-amber-600" />
              <span>FIELD REPAIR ACTIONS</span>
            </div>

            <div className="space-y-1.5">
              {activeFault === 'blown_fuse' && (
                <button
                  onClick={() => handleRepairAction('fuse', 'Replace 40A 1000V DC Ceramic Fuse')}
                  disabled={fixedActions.includes('fuse')}
                  className={`w-full py-2 px-3 text-xs font-medium rounded-lg text-left transition-colors flex items-center justify-between ${
                    fixedActions.includes('fuse')
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                  }`}
                >
                  <span>1. Replace Blown 40A DC Fuse</span>
                  {fixedActions.includes('fuse') && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                </button>
              )}

              {activeFault === 'loose_mc4' && (
                <button
                  onClick={() => handleRepairAction('mc4', 'Re-crimp & click MC4 connector locking ring')}
                  disabled={fixedActions.includes('mc4')}
                  className={`w-full py-2 px-3 text-xs font-medium rounded-lg text-left transition-colors flex items-center justify-between ${
                    fixedActions.includes('mc4')
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                  }`}
                >
                  <span>1. Re-seat & Lock MC4 Connector</span>
                  {fixedActions.includes('mc4') && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                </button>
              )}

              {activeFault === 'ground_fault' && (
                <button
                  onClick={() => handleRepairAction('ground', 'Drain conduit moisture & replace nicked cable')}
                  disabled={fixedActions.includes('ground')}
                  className={`w-full py-2 px-3 text-xs font-medium rounded-lg text-left transition-colors flex items-center justify-between ${
                    fixedActions.includes('ground')
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                  }`}
                >
                  <span>1. Insulate Conduit & Clear Moisture</span>
                  {fixedActions.includes('ground') && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                </button>
              )}

              <button
                onClick={() => handleRepairAction('reboot', 'Power cycle inverter & verify AC synchronization')}
                className="w-full py-2 px-3 text-xs font-medium rounded-lg text-left bg-slate-100 hover:bg-slate-200 text-slate-800 transition-colors"
              >
                2. Cycle DC Disconnect & Verify Inverter
              </button>
            </div>

            {/* Complete Practical Lab Button */}
            <div className="pt-2">
              <button
                onClick={handleFinishLab}
                disabled={labSubmitted}
                className={`w-full py-2.5 px-4 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-all shadow-sm ${
                  isResolved
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    : 'bg-slate-900 hover:bg-slate-800 text-white'
                }`}
              >
                <Award className="w-4 h-4" />
                <span>{labSubmitted ? 'Practical Assessment Recorded!' : 'Submit Lab for Certification'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
