import React, { useState } from 'react';
import { JobOpportunity } from '../types';
import { X, Briefcase, PlusCircle } from 'lucide-react';

interface PostJobModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddJob: (newJob: JobOpportunity) => void;
}

export const PostJobModal: React.FC<PostJobModalProps> = ({
  isOpen,
  onClose,
  onAddJob,
}) => {
  const [title, setTitle] = useState('');
  const [employer, setEmployer] = useState('');
  const [location, setLocation] = useState('Nairobi, Kenya');
  const [city, setCity] = useState('Nairobi');
  const [monthlyWage, setMonthlyWage] = useState('KES 48,000 / month');
  const [whatsapp, setWhatsapp] = useState('+254700000000');
  const [trackId, setTrackId] = useState('solar_pv_tech');
  const [description, setDescription] = useState('');
  const [vacancies, setVacancies] = useState(3);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !employer) return;

    const newJob: JobOpportunity = {
      id: `job_${Date.now()}`,
      title,
      employer,
      verifiedEmployer: true,
      location,
      city,
      country: 'Kenya',
      trackId,
      monthlyWage,
      dailyRate: 'KES 2,000 / day',
      stipendPerks: ['Field Toolkit Provided', 'Transport Allowance', 'Apprenticeship Bonus'],
      jobType: 'Full-time',
      vacancies: Number(vacancies) || 1,
      postedDate: 'Just now',
      whatsappContact: whatsapp,
      smsNumber: whatsapp,
      requiredCertificate: 'Certified Vocational Technician',
      description: description || 'Seeking skilled vocational technician with practical lab certification.',
    };

    onAddJob(newJob);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-amber-400" />
            <span className="font-bold text-sm">Post a Certified Vocational Opening</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div>
            <label className="text-slate-700 font-semibold block mb-1">Job Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Lead Rooftop Solar PV Technician"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-700 font-semibold block mb-1">Company / Enterprise</label>
              <input
                type="text"
                required
                value={employer}
                onChange={(e) => setEmployer(e.target.value)}
                placeholder="e.g. SolarGrid Africa Ltd"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-slate-700 font-semibold block mb-1">Vocational Trade</label>
              <select
                value={trackId}
                onChange={(e) => setTrackId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none"
              >
                <option value="solar_pv_tech">Solar & Mini-Grids</option>
                <option value="ev_boda_mechanic">EV & Boda Mechanics</option>
                <option value="health_cold_chain">Healthcare Cold-Chain</option>
                <option value="smart_irrigation_tech">Solar Irrigation</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-700 font-semibold block mb-1">Location & City</label>
              <input
                type="text"
                value={location}
                onChange={(e) => {
                  setLocation(e.target.value);
                  setCity(e.target.value.split(',')[0].trim());
                }}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-slate-700 font-semibold block mb-1">Monthly Wage & Currency</label>
              <input
                type="text"
                value={monthlyWage}
                onChange={(e) => setMonthlyWage(e.target.value)}
                placeholder="e.g. KES 50,000 / month"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-700 font-semibold block mb-1">Recruiter WhatsApp</label>
              <input
                type="text"
                value={whatsapp}
                onChange={(e) => setWhatsapp(e.target.value)}
                placeholder="+254..."
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-slate-700 font-semibold block mb-1">Open Positions</label>
              <input
                type="number"
                min="1"
                max="50"
                value={vacancies}
                onChange={(e) => setVacancies(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="text-slate-700 font-semibold block mb-1">Role Description</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe daily field duties, tools supplied, and requirements..."
              className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-colors"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Publish Verified Job Opportunity</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
