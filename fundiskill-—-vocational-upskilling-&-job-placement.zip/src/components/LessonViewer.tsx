import React, { useState } from 'react';
import { CourseModule } from '../types';
import { 
  Volume2, 
  VolumeX, 
  CheckSquare, 
  Square, 
  AlertCircle, 
  CheckCircle2, 
  ArrowRight,
  ShieldCheck,
  ChevronLeft
} from 'lucide-react';

interface LessonViewerProps {
  module: CourseModule;
  isCompleted: boolean;
  onComplete: () => void;
  onBack: () => void;
  onLaunchSimulator: (simId: string) => void;
  simulatorId: string;
}

export const LessonViewer: React.FC<LessonViewerProps> = ({
  module,
  isCompleted,
  onComplete,
  onBack,
  onLaunchSimulator,
  simulatorId
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [checkedItems, setCheckedItems] = useState<number[]>([]);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);

  const toggleCheck = (idx: number) => {
    setCheckedItems(prev => 
      prev.includes(idx) ? prev.filter(i => i !== idx) : [...prev, idx]
    );
  };

  const handleToggleAudio = () => {
    if ('speechSynthesis' in window) {
      if (isPlayingAudio) {
        window.speechSynthesis.cancel();
        setIsPlayingAudio(false);
      } else {
        setIsPlayingAudio(true);
        const utterance = new SpeechSynthesisUtterance(module.audioScript);
        utterance.rate = 0.95;
        utterance.onend = () => setIsPlayingAudio(false);
        utterance.onerror = () => setIsPlayingAudio(false);
        window.speechSynthesis.speak(utterance);
      }
    }
  };

  const handleSelectAnswer = (qId: string, optIdx: number) => {
    if (!quizSubmitted) {
      setSelectedAnswers(prev => ({ ...prev, [qId]: optIdx }));
    }
  };

  const areAllQuestionsAnswered = module.diagnosticQuiz.every(q => selectedAnswers[q.id] !== undefined);
  const correctCount = module.diagnosticQuiz.filter(q => selectedAnswers[q.id] === q.correctIndex).length;
  const isQuizPassed = correctCount === module.diagnosticQuiz.length;

  const handleFinishModule = () => {
    onComplete();
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-12">
      {/* Back button & module title */}
      <div>
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-medium text-slate-500 hover:text-slate-800 transition-colors mb-2"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Back to Curriculum</span>
        </button>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
              <span>{module.readTimeMin} min read</span>
              <span>·</span>
              <span>{module.audioDurationMin} min audio</span>
              <span>·</span>
              <span className="text-emerald-700 font-semibold font-mono">14 KB payload</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              {module.title}
            </h1>
          </div>

          {/* Voice Audio Listen Button */}
          <button
            onClick={handleToggleAudio}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium transition-colors shrink-0 shadow-sm ${
              isPlayingAudio
                ? 'bg-amber-500 text-slate-950 font-semibold'
                : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-50'
            }`}
          >
            {isPlayingAudio ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-amber-600" />}
            <span>{isPlayingAudio ? 'Pause Narration' : 'Listen Read-Aloud'}</span>
          </button>
        </div>
      </div>

      {/* Key Skills Checklist Bar */}
      <div className="flex flex-wrap gap-2 text-xs">
        {module.keySkills.map((skill, idx) => (
          <span key={idx} className="bg-slate-100 text-slate-700 font-medium px-2.5 py-1 rounded-md">
            ✓ {skill}
          </span>
        ))}
      </div>

      {/* Core Technical Brief */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
        <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Vocational Field Brief</h3>
        <p className="text-sm text-slate-700 leading-relaxed">
          {module.summary}
        </p>

        {/* Audio Script / Transcription Box */}
        <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs text-slate-600 leading-relaxed italic">
          <div className="text-[11px] font-bold text-slate-500 not-italic uppercase mb-1">Narrator Transcript:</div>
          "{module.audioScript}"
        </div>
      </div>

      {/* Interactive Safety & Procedure Checklist */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>MANDATORY PROTOCOL CHECKLIST</span>
          </h3>
          <span className="text-xs font-mono text-slate-500">
            {checkedItems.length}/{module.checklist.length} Completed
          </span>
        </div>

        <div className="space-y-2">
          {module.checklist.map((item, idx) => {
            const isChecked = checkedItems.includes(idx);
            return (
              <div
                key={idx}
                onClick={() => toggleCheck(idx)}
                className={`p-3 rounded-xl border cursor-pointer transition-all flex items-start gap-3 text-xs ${
                  isChecked
                    ? 'bg-emerald-50/60 border-emerald-300 text-emerald-950 font-medium'
                    : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700'
                }`}
              >
                <div className="mt-0.5">
                  {isChecked ? (
                    <CheckSquare className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <Square className="w-4 h-4 text-slate-400" />
                  )}
                </div>
                <span>{item}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Launch Practical Lab Banner */}
      <div className="bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 p-4 sm:p-5 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-md">
        <div>
          <div className="text-xs font-extrabold uppercase tracking-wider text-amber-950">Hands-on Assessment Lab</div>
          <div className="text-base font-bold mt-0.5">Ready to test these skills on real virtual hardware?</div>
          <div className="text-xs text-amber-950/80 mt-1">Simulate multimeter readings and diagnose real faults without consuming mobile data.</div>
        </div>

        <button
          onClick={() => onLaunchSimulator(simulatorId)}
          className="px-4 py-2.5 bg-slate-950 hover:bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-transform active:scale-95 shrink-0"
        >
          <span>Launch Practical Simulator</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Diagnostic Micro-Quiz */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900">DIAGNOSTIC KNOWLEDGE CHECK</h3>
          <p className="text-xs text-slate-500 mt-0.5">Answer all questions correctly to mark this module completed.</p>
        </div>

        <div className="space-y-4">
          {module.diagnosticQuiz.map((q, qIndex) => {
            const chosen = selectedAnswers[q.id];
            const isCorrect = chosen === q.correctIndex;

            return (
              <div key={q.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2.5">
                <div className="text-xs font-semibold text-slate-900">
                  {qIndex + 1}. {q.question}
                </div>

                <div className="space-y-1.5">
                  {q.options.map((opt, optIndex) => {
                    const isSelected = chosen === optIndex;
                    return (
                      <button
                        key={optIndex}
                        onClick={() => handleSelectAnswer(q.id, optIndex)}
                        className={`w-full text-left p-2.5 rounded-lg text-xs transition-colors flex items-center justify-between ${
                          isSelected
                            ? (quizSubmitted
                                ? (optIndex === q.correctIndex
                                    ? 'bg-emerald-100 text-emerald-950 border border-emerald-400 font-medium'
                                    : 'bg-red-100 text-red-950 border border-red-300 font-medium')
                                : 'bg-slate-900 text-white font-medium')
                            : (quizSubmitted && optIndex === q.correctIndex
                                ? 'bg-emerald-50 text-emerald-900 border border-emerald-300 font-medium'
                                : 'bg-white border border-slate-200 hover:border-slate-300 text-slate-700')
                        }`}
                      >
                        <span>{opt}</span>
                        {quizSubmitted && optIndex === q.correctIndex && (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>

                {quizSubmitted && (
                  <div className={`p-2.5 rounded-lg text-xs ${isCorrect ? 'bg-emerald-50 text-emerald-900' : 'bg-amber-50 text-amber-900'}`}>
                    <div className="font-semibold">{isCorrect ? 'Correct!' : 'Incorrect'}</div>
                    <div className="text-[11px] mt-0.5">{q.explanation}</div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Submit Quiz & Complete */}
        <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
          {!quizSubmitted ? (
            <button
              onClick={() => setQuizSubmitted(true)}
              disabled={!areAllQuestionsAnswered}
              className={`w-full sm:w-auto px-5 py-2.5 rounded-xl text-xs font-bold transition-colors ${
                areAllQuestionsAnswered
                  ? 'bg-slate-900 hover:bg-slate-800 text-white'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              Verify Quiz Answers
            </button>
          ) : (
            <button
              onClick={handleFinishModule}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center gap-2 shadow-sm"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isCompleted ? 'Module Already Completed' : 'Save & Mark Module Complete'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
