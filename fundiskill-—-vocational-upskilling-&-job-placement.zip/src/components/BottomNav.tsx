import React from 'react';
import { 
  BookOpen, 
  Cpu, 
  Award, 
  Briefcase, 
  UserCheck
} from 'lucide-react';

interface BottomNavProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  earnedCertCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onTabChange,
  earnedCertCount,
}) => {
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 h-16 px-2 flex items-center justify-around">
      <button
        onClick={() => onTabChange('tracks')}
        className={`flex-1 min-h-[48px] flex flex-col items-center justify-center transition-colors ${
          currentTab === 'tracks' ? 'text-slate-950 font-bold' : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <BookOpen className="w-5 h-5" />
        <span className="text-[10px] mt-1 tracking-tight">Tracks</span>
      </button>

      <button
        onClick={() => onTabChange('simulators')}
        className={`flex-1 min-h-[48px] flex flex-col items-center justify-center transition-colors ${
          currentTab === 'simulators' ? 'text-slate-950 font-bold' : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <Cpu className="w-5 h-5" />
        <span className="text-[10px] mt-1 tracking-tight">Labs</span>
      </button>

      <button
        onClick={() => onTabChange('certificates')}
        className={`flex-1 min-h-[48px] flex flex-col items-center justify-center relative transition-colors ${
          currentTab === 'certificates' ? 'text-slate-950 font-bold' : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <Award className="w-5 h-5" />
        <span className="text-[10px] mt-1 tracking-tight">Certs</span>
        {earnedCertCount > 0 && (
          <span className="absolute top-1.5 right-4 w-4 h-4 bg-amber-500 text-slate-950 text-[9px] font-bold rounded-full flex items-center justify-center">
            {earnedCertCount}
          </span>
        )}
      </button>

      <button
        onClick={() => onTabChange('jobs')}
        className={`flex-1 min-h-[48px] flex flex-col items-center justify-center transition-colors ${
          currentTab === 'jobs' ? 'text-slate-950 font-bold' : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <Briefcase className="w-5 h-5" />
        <span className="text-[10px] mt-1 tracking-tight">Jobs</span>
      </button>

      <button
        onClick={() => onTabChange('passport')}
        className={`flex-1 min-h-[48px] flex flex-col items-center justify-center transition-colors ${
          currentTab === 'passport' ? 'text-slate-950 font-bold' : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <UserCheck className="w-5 h-5" />
        <span className="text-[10px] mt-1 tracking-tight">Passport</span>
      </button>
    </nav>
  );
};
