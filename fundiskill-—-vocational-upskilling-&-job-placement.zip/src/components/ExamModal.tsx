import React, { useState } from 'react';
import { VocationalTrack, CertificateRecord } from '../types';
import { Award, CheckCircle2, AlertCircle, X, ShieldCheck } from 'lucide-react';

interface ExamModalProps {
  track: VocationalTrack | null;
  isOpen: boolean;
  onClose: () => void;
  onPassExam: (cert: CertificateRecord) => void;
  studentName: string;
}

export const ExamModal: React.FC<ExamModalProps> = ({
  track,
  isOpen,
  onClose,
  onPassExam,
  studentName,
}) => {
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [isFinished, setIsFinished] = useState(false);

  if (!isOpen || !track) return null;

  // Flatten all questions across track modules
  const allQuestions = track.modules.flatMap(m => m.diagnosticQuiz);

  const currentQ = allQuestions[currentQIndex] || allQuestions[0];

  const handleSelect = (optIndex: number) => {
    const updated = [...selectedAnswers];
    updated[currentQIndex] = optIndex;
    setSelectedAnswers(updated);
  };

  const handleNext = () => {
    if (currentQIndex < allQuestions.length - 1) {
      setCurrentQIndex(currentQIndex + 1);
    } else {
      setIsFinished(true);
    }
  };

  const correctAnswersCount = allQuestions.filter((q, idx) => selectedAnswers[idx] === q.correctIndex).length;
  const scorePercent = Math.round((correctAnswersCount / (allQuestions.length || 1)) * 100);
  const isPassed = scorePercent >= 70;

  const handleClaimCertificate = () => {
    const randomHex = Math.random().toString(16).substring(2, 10).toUpperCase();
    const newCert: CertificateRecord = {
      id: `FS-KE-${Math.floor(100000 + Math.random() * 900000)}`,
      trackId: track.id,
      trackTitle: track.certificateTitle,
      studentName: studentName || 'Grace Mwangi',
      issueDate: 'September 2026',
      theoryScore: Math.max(scorePercent, 82),
      practicalScore: 96,
      safetyRubricScore: 100,
      verifierOrganization: 'Vocational Technical Training Consortium (TVET)',
      qrCodeSeed: `https://fundiskill.org/verify/FS-KE-${randomHex}`,
      blockchainHash: `0x7f4c9a8b1d2e3f5a6b7c8d9e0f1a2b3c4d5e6f7a${randomHex}`,
    };

    onPassExam(newCert);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            <div>
              <div className="text-xs uppercase font-bold text-amber-400 tracking-wider">
                CERTIFICATION ASSESSMENT
              </div>
              <div className="text-xs text-slate-300 font-semibold truncate max-w-xs">{track.title}</div>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {!isFinished ? (
            <div className="space-y-4">
              <div className="flex justify-between items-center text-xs text-slate-500 font-mono pb-2 border-b border-slate-100">
                <span>QUESTION {currentQIndex + 1} OF {allQuestions.length}</span>
                <span>Pass mark: 70%</span>
              </div>

              <div className="text-sm font-bold text-slate-900 leading-snug">
                {currentQ.question}
              </div>

              <div className="space-y-2">
                {currentQ.options.map((opt, optIdx) => {
                  const isSelected = selectedAnswers[currentQIndex] === optIdx;
                  return (
                    <button
                      key={optIdx}
                      onClick={() => handleSelect(optIdx)}
                      className={`w-full text-left p-3 rounded-xl border text-xs font-medium transition-colors ${
                        isSelected
                          ? 'bg-slate-900 text-white border-slate-900 font-bold'
                          : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700'
                      }`}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>

              <div className="pt-3">
                <button
                  onClick={handleNext}
                  disabled={selectedAnswers[currentQIndex] === undefined}
                  className={`w-full py-3 rounded-xl text-xs font-bold transition-colors ${
                    selectedAnswers[currentQIndex] !== undefined
                      ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-sm'
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  {currentQIndex < allQuestions.length - 1 ? 'Next Question →' : 'Submit Final Assessment'}
                </button>
              </div>
            </div>
          ) : (
            <div className="text-center space-y-4 py-2">
              <div className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center ${isPassed ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}>
                {isPassed ? <CheckCircle2 className="w-10 h-10" /> : <AlertCircle className="w-10 h-10" />}
              </div>

              <div>
                <h3 className="text-xl font-bold text-slate-900">
                  {isPassed ? 'Congratulations! Assessment Passed' : 'Assessment Incomplete'}
                </h3>
                <div className="text-xs text-slate-500 mt-1 font-mono">
                  Your Score: <span className="font-bold text-slate-900 text-sm">{scorePercent}%</span> (Passing score: 70%)
                </div>
              </div>

              {isPassed ? (
                <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-900 space-y-2 text-left">
                  <div className="font-bold flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Industry Competency Confirmed</span>
                  </div>
                  <div className="text-[11px] text-emerald-800 leading-relaxed">
                    You have satisfied technical theory requirements. Your certified micro-credential will be issued and registered in the public verification directory.
                  </div>
                  <button
                    onClick={handleClaimCertificate}
                    className="w-full mt-2 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition-colors"
                  >
                    Issue Official Verified Credential
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => {
                    setIsFinished(false);
                    setCurrentQIndex(0);
                    setSelectedAnswers([]);
                  }}
                  className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs transition-colors"
                >
                  Review Curriculum & Retake Exam
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
