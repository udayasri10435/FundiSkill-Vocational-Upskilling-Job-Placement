import React, { useState } from 'react';
import { VocationalTrack, CourseModule } from '../types';
import { 
  Sun, 
  Zap, 
  ShieldPlus, 
  Droplets, 
  DownloadCloud, 
  Check, 
  ArrowRight, 
  Clock, 
  Cpu, 
  DollarSign,
  Award,
  ChevronRight,
  BookOpen
} from 'lucide-react';

interface CourseCatalogProps {
  tracks: VocationalTrack[];
  completedModules: string[];
  downloadedTracks: string[];
  onSelectModule: (module: CourseModule, track: VocationalTrack) => void;
  onLaunchSimulator: (simulatorId: string) => void;
  onDownloadTrack: (trackId: string) => void;
  onTakeExam: (track: VocationalTrack) => void;
}

export const CourseCatalog: React.FC<CourseCatalogProps> = ({
  tracks,
  completedModules,
  downloadedTracks,
  onSelectModule,
  onLaunchSimulator,
  onDownloadTrack,
  onTakeExam,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [expandedTrackId, setExpandedTrackId] = useState<string>(tracks[0]?.id || '');

  const filteredTracks = selectedCategory === 'all'
    ? tracks
    : tracks.filter(t => t.category === selectedCategory);

  const getTrackIcon = (iconName: string) => {
    switch (iconName) {
      case 'Sun': return <Sun className="w-5 h-5 text-amber-500" />;
      case 'Zap': return <Zap className="w-5 h-5 text-sky-500" />;
      case 'ShieldPlus': return <ShieldPlus className="w-5 h-5 text-emerald-500" />;
      case 'Droplets': return <Droplets className="w-5 h-5 text-cyan-500" />;
      default: return <BookOpen className="w-5 h-5 text-slate-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Category Segmented Tabs (Compliant with buttons/tabs guidelines) */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-200/80 rounded-xl overflow-x-auto no-scrollbar text-xs">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`px-3.5 py-1.5 font-medium rounded-lg whitespace-nowrap transition-colors ${
            selectedCategory === 'all'
              ? 'bg-white text-slate-900 shadow-sm font-semibold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          All High-Growth Trades ({tracks.length})
        </button>
        <button
          onClick={() => setSelectedCategory('clean_energy')}
          className={`px-3.5 py-1.5 font-medium rounded-lg whitespace-nowrap transition-colors ${
            selectedCategory === 'clean_energy'
              ? 'bg-white text-slate-900 shadow-sm font-semibold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Solar & Mini-Grids
        </button>
        <button
          onClick={() => setSelectedCategory('e_mobility')}
          className={`px-3.5 py-1.5 font-medium rounded-lg whitespace-nowrap transition-colors ${
            selectedCategory === 'e_mobility'
              ? 'bg-white text-slate-900 shadow-sm font-semibold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          EV & Boda-Boda
        </button>
        <button
          onClick={() => setSelectedCategory('health_tech')}
          className={`px-3.5 py-1.5 font-medium rounded-lg whitespace-nowrap transition-colors ${
            selectedCategory === 'health_tech'
              ? 'bg-white text-slate-900 shadow-sm font-semibold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Healthcare Cold-Chain
        </button>
        <button
          onClick={() => setSelectedCategory('agri_water')}
          className={`px-3.5 py-1.5 font-medium rounded-lg whitespace-nowrap transition-colors ${
            selectedCategory === 'agri_water'
              ? 'bg-white text-slate-900 shadow-sm font-semibold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Solar Irrigation
        </button>
      </div>

      {/* Track Cards */}
      <div className="space-y-4">
        {filteredTracks.map((track) => {
          const isDownloaded = downloadedTracks.includes(track.id);
          const isExpanded = expandedTrackId === track.id;
          const completedCount = track.modules.filter(m => completedModules.includes(m.id)).length;
          const progressPercent = Math.round((completedCount / track.modules.length) * 100);

          return (
            <div
              key={track.id}
              className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden transition-all"
            >
              {/* Card Header Info */}
              <div className="p-4 sm:p-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center shrink-0 border border-slate-200">
                      {getTrackIcon(track.iconName)}
                    </div>
                    <div>
                      {/* Zero-Pill Unboxed Metadata with · separator */}
                      <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500 mb-1">
                        <span className="font-semibold text-slate-700">{track.marketDemand} Demand</span>
                        <span aria-hidden="true">·</span>
                        <span>{track.avgEntryWage}</span>
                        <span aria-hidden="true">·</span>
                        <span>{track.regionFocus.join(', ')}</span>
                      </div>
                      <h3 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                        {track.title}
                      </h3>
                    </div>
                  </div>

                  {/* Offline Download Button */}
                  <button
                    onClick={() => onDownloadTrack(track.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors shrink-0 ${
                      isDownloaded
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                    title="Download ultra-lightweight pack for zero-data offline learning"
                  >
                    {isDownloaded ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <DownloadCloud className="w-3.5 h-3.5" />}
                    <span>{isDownloaded ? 'Saved Offline' : `${track.dataPackSizeKb}KB Offline Pack`}</span>
                  </button>
                </div>

                <p className="text-xs text-slate-600 mt-2.5 leading-relaxed">
                  {track.description}
                </p>

                {/* Progress bar */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex justify-between text-xs text-slate-600 mb-1">
                      <span>Curriculum Progress: {completedCount}/{track.modules.length} lessons</span>
                      <span className="font-mono font-bold">{progressPercent}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-slate-900 transition-all duration-300 rounded-full"
                        style={{ width: `${progressPercent}%` }}
                      />
                    </div>
                  </div>

                  <button
                    onClick={() => setExpandedTrackId(isExpanded ? '' : track.id)}
                    className="px-3 py-1.5 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
                  >
                    {isExpanded ? 'Hide Modules' : 'View Modules'}
                  </button>
                </div>
              </div>

              {/* Collapsible Module List & Action Buttons */}
              {isExpanded && (
                <div className="bg-slate-50 border-t border-slate-200 p-4 sm:p-5 space-y-3">
                  <div className="text-xs font-bold text-slate-600 tracking-wider">
                    MODULES & MICRO-LESSONS
                  </div>

                  <div className="space-y-2">
                    {track.modules.map((mod, idx) => {
                      const isModCompleted = completedModules.includes(mod.id);
                      return (
                        <div
                          key={mod.id}
                          onClick={() => onSelectModule(mod, track)}
                          className="p-3.5 bg-white rounded-xl border border-slate-200 hover:border-slate-300 shadow-sm cursor-pointer transition-all flex items-center justify-between gap-3 group"
                        >
                          <div className="flex items-center gap-3">
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-mono font-bold shrink-0 ${
                              isModCompleted ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'
                            }`}>
                              {isModCompleted ? '✓' : idx + 1}
                            </div>
                            <div>
                              <div className="text-xs font-bold text-slate-900 group-hover:text-amber-800 transition-colors">
                                {mod.title}
                              </div>
                              <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                                <span>{mod.readTimeMin} min read</span>
                                <span>·</span>
                                <span>Audio narration included</span>
                              </div>
                            </div>
                          </div>

                          <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-slate-700 transition-colors shrink-0" />
                        </div>
                      );
                    })}
                  </div>

                  {/* Lab & Exam Launch Bar */}
                  <div className="pt-3 flex flex-col sm:flex-row items-center gap-2">
                    <button
                      onClick={() => onLaunchSimulator(track.simulatorId)}
                      className="w-full sm:flex-1 py-2.5 px-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                    >
                      <Cpu className="w-4 h-4" />
                      <span>Launch Interactive Hardware Lab</span>
                    </button>

                    <button
                      onClick={() => onTakeExam(track)}
                      className="w-full sm:w-auto py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <Award className="w-4 h-4" />
                      <span>Take Certification Exam</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
