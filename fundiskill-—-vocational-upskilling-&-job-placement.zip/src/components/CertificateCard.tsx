import React from 'react';
import { CertificateRecord } from '../types';
import { 
  Award, 
  Share2, 
  Printer, 
  CheckCircle2, 
  ExternalLink, 
  ShieldCheck, 
  QrCode,
  Copy
} from 'lucide-react';

interface CertificateCardProps {
  certificate: CertificateRecord;
  onVerifyModalOpen: (certId: string) => void;
}

export const CertificateCard: React.FC<CertificateCardProps> = ({
  certificate,
  onVerifyModalOpen,
}) => {
  const handleShareWhatsApp = () => {
    const text = encodeURIComponent(
      `Hello! Here is my verified vocational trade credential: ${certificate.trackTitle}.\n` +
      `Candidate: ${certificate.studentName}\n` +
      `Credential ID: ${certificate.id}\n` +
      `Practical Lab Score: ${certificate.practicalScore}%\n` +
      `Theory Score: ${certificate.theoryScore}%\n` +
      `Verify on FundiSkill Registry: ${window.location.origin}?verify=${certificate.id}`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCopyLink = () => {
    const link = `${window.location.origin}?verify=${certificate.id}`;
    navigator.clipboard?.writeText(link);
    alert('Verification link copied to clipboard!');
  };

  return (
    <div className="bg-white rounded-3xl border-2 border-slate-900 shadow-xl overflow-hidden max-w-2xl mx-auto my-4 print:shadow-none print:border-slate-800">
      {/* Certificate Top Security Guilloche Bar */}
      <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b-2 border-amber-500">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-500 flex items-center justify-center text-slate-950 font-black">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs uppercase tracking-widest font-bold text-amber-400">
              NATIONAL VOCATIONAL SKILLS REGISTRY
            </div>
            <div className="text-[11px] text-slate-400 font-mono">
              TAMPER-PROOF VERIFIED MICRO-CREDENTIAL
            </div>
          </div>
        </div>

        <div className="text-right">
          <div className="text-[10px] text-slate-400 font-mono">CREDENTIAL ID</div>
          <div className="text-xs font-mono font-bold text-white tracking-wider">{certificate.id}</div>
        </div>
      </div>

      {/* Main Certificate Body */}
      <div className="p-6 sm:p-8 space-y-6 relative bg-[radial-gradient(#f1f5f9_1px,transparent_1px)] [background-size:16px_16px]">
        {/* Verification Watermark */}
        <div className="text-center space-y-2">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            This is to certify that
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-950 tracking-tight">
            {certificate.studentName}
          </h2>
          <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
            has demonstrated assessed technical competency, hands-on diagnostic troubleshooting, and safety compliance in accordance with industry benchmarks for:
          </p>
          <div className="pt-2">
            <span className="inline-block text-base sm:text-lg font-bold text-amber-950 bg-amber-50 border border-amber-300 px-4 py-1.5 rounded-xl">
              {certificate.trackTitle}
            </span>
          </div>
        </div>

        {/* Skill Rubric Breakdown */}
        <div className="grid grid-cols-3 gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-200 text-center font-mono">
          <div>
            <div className="text-[11px] text-slate-500 uppercase">Theory Score</div>
            <div className="text-lg sm:text-xl font-extrabold text-slate-900 mt-0.5">
              {certificate.theoryScore}%
            </div>
            <div className="text-[10px] text-emerald-600 font-semibold mt-0.5">✓ PASSED</div>
          </div>

          <div className="border-x border-slate-200">
            <div className="text-[11px] text-slate-500 uppercase">Practical Lab</div>
            <div className="text-lg sm:text-xl font-extrabold text-slate-900 mt-0.5">
              {certificate.practicalScore}%
            </div>
            <div className="text-[10px] text-emerald-600 font-semibold mt-0.5">✓ CALIBRATED</div>
          </div>

          <div>
            <div className="text-[11px] text-slate-500 uppercase">Safety Protocol</div>
            <div className="text-lg sm:text-xl font-extrabold text-slate-900 mt-0.5">
              {certificate.safetyRubricScore}%
            </div>
            <div className="text-[10px] text-emerald-600 font-semibold mt-0.5">✓ 100% PPE</div>
          </div>
        </div>

        {/* Bottom Signatures & QR Block */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-200 text-xs">
          <div className="flex items-center gap-3">
            {/* Simulated Verified QR Code */}
            <div className="p-2 bg-white border border-slate-300 rounded-xl shadow-xs">
              <QrCode className="w-12 h-12 text-slate-900" />
            </div>
            <div className="space-y-0.5">
              <div className="font-bold text-slate-900 flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Verified Authority</span>
              </div>
              <div className="text-slate-500 text-[11px]">{certificate.verifierOrganization}</div>
              <div className="text-slate-400 font-mono text-[10px] truncate max-w-[200px]">
                SHA-256: {certificate.blockchainHash.slice(0, 18)}...
              </div>
            </div>
          </div>

          <div className="text-right space-y-0.5">
            <div className="text-slate-400 text-[11px]">DATE OF ISSUANCE</div>
            <div className="font-bold font-mono text-slate-900">{certificate.issueDate}</div>
            <div className="text-emerald-700 font-semibold text-[11px]">ACTIVE & VALID</div>
          </div>
        </div>
      </div>

      {/* Action Bar (Share to WhatsApp, Print, Verify) - hidden during print */}
      <div className="p-4 bg-slate-100 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 no-print">
        <div className="flex items-center gap-2">
          <button
            onClick={handleShareWhatsApp}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Share to Employer on WhatsApp</span>
          </button>

          <button
            onClick={handleCopyLink}
            className="px-3 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>Copy Link</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="px-3 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print License</span>
          </button>

          <button
            onClick={() => onVerifyModalOpen(certificate.id)}
            className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Public Verification</span>
          </button>
        </div>
      </div>
    </div>
  );
};
