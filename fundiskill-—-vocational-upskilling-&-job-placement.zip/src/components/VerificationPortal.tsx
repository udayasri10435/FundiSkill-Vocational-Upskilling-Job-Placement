import React, { useState } from 'react';
import { CertificateRecord } from '../types';
import { 
  ShieldCheck, 
  Search, 
  CheckCircle2, 
  X, 
  AlertCircle,
  Building,
  Calendar,
  Award
} from 'lucide-react';

interface VerificationPortalProps {
  isOpen: boolean;
  onClose: () => void;
  certificates: CertificateRecord[];
  initialCertId?: string;
}

export const VerificationPortal: React.FC<VerificationPortalProps> = ({
  isOpen,
  onClose,
  certificates,
  initialCertId = '',
}) => {
  const [searchId, setSearchId] = useState(initialCertId);
  const [matchedCert, setMatchedCert] = useState<CertificateRecord | null>(
    certificates.find(c => c.id.toLowerCase() === initialCertId.toLowerCase()) || certificates[0] || null
  );
  const [hasSearched, setHasSearched] = useState(false);

  if (!isOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setHasSearched(true);
    const found = certificates.find(c => c.id.toLowerCase() === searchId.trim().toLowerCase());
    setMatchedCert(found || null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-xl w-full overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Top Bar */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <div>
              <div className="text-xs uppercase tracking-wider font-bold text-amber-400">
                Official Credential Registry
              </div>
              <div className="text-[11px] text-slate-400">Instant Public Verification Portal</div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-6 space-y-4">
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                value={searchId}
                onChange={(e) => setSearchId(e.target.value)}
                placeholder="Enter Credential ID (e.g. FS-KE-849201)"
                className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold shrink-0"
            >
              Verify Now
            </button>
          </form>

          {/* Verification Result */}
          {matchedCert ? (
            <div className="p-5 bg-emerald-50/60 border border-emerald-300 rounded-2xl space-y-3 font-sans">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  AUTHENTIC & VALID CREDENTIAL
                </span>
                <span className="text-[11px] font-mono text-emerald-700">ID: {matchedCert.id}</span>
              </div>

              <div className="space-y-1">
                <div className="text-xs text-slate-500">Certified Professional:</div>
                <div className="text-base font-bold text-slate-900">{matchedCert.studentName}</div>
                <div className="text-xs font-semibold text-amber-800">{matchedCert.trackTitle}</div>
              </div>

              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-emerald-200 text-center font-mono text-xs">
                <div className="bg-white p-2 rounded-lg border border-emerald-200">
                  <div className="text-[10px] text-slate-500">Theory</div>
                  <div className="font-bold text-slate-900">{matchedCert.theoryScore}%</div>
                </div>
                <div className="bg-white p-2 rounded-lg border border-emerald-200">
                  <div className="text-[10px] text-slate-500">Practical Lab</div>
                  <div className="font-bold text-slate-900">{matchedCert.practicalScore}%</div>
                </div>
                <div className="bg-white p-2 rounded-lg border border-emerald-200">
                  <div className="text-[10px] text-slate-500">Safety Rubric</div>
                  <div className="font-bold text-slate-900">{matchedCert.safetyRubricScore}%</div>
                </div>
              </div>

              <div className="pt-2 text-[11px] text-slate-600 space-y-1">
                <div className="flex items-center gap-1.5">
                  <Building className="w-3.5 h-3.5 text-slate-500" />
                  <span>Issuing Body: {matchedCert.verifierOrganization}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-500" />
                  <span>Date Issued: {matchedCert.issueDate}</span>
                </div>
                <div className="font-mono text-[10px] text-slate-400 truncate">
                  Hash: {matchedCert.blockchainHash}
                </div>
              </div>
            </div>
          ) : (
            hasSearched && (
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-xs text-amber-800 flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
                <div>
                  <div className="font-bold">Credential Not Found in Registry</div>
                  <div className="text-[11px] mt-0.5 text-amber-700">
                    Check the ID string for typos or ensure the candidate has passed both theory and practical lab modules.
                  </div>
                </div>
              </div>
            )
          )}
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-200 text-center text-xs text-slate-500">
          FundiSkill National Trade Registry · Certified by East African Renewable Energy & Vocational Consortium
        </div>
      </div>
    </div>
  );
};
