import React, { useState } from 'react';
import { JobOpportunity, JobApplication, CertificateRecord } from '../types';
import { 
  Briefcase, 
  MapPin, 
  DollarSign, 
  CheckCircle2, 
  Share2, 
  PhoneCall, 
  MessageSquare, 
  PlusCircle, 
  Search,
  Filter,
  ShieldCheck,
  Sparkles,
  ArrowRight
} from 'lucide-react';

interface JobBoardProps {
  jobs: JobOpportunity[];
  applications: JobApplication[];
  earnedCertificates: CertificateRecord[];
  onApplyJob: (job: JobOpportunity) => void;
  onOpenPostJob: () => void;
  workerName: string;
}

export const JobBoard: React.FC<JobBoardProps> = ({
  jobs,
  applications,
  earnedCertificates,
  onApplyJob,
  onOpenPostJob,
  workerName,
}) => {
  const [selectedCity, setSelectedCity] = useState<string>('all');
  const [selectedTrade, setSelectedTrade] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredJobs = jobs.filter(job => {
    if (selectedCity !== 'all' && job.city.toLowerCase() !== selectedCity.toLowerCase()) return false;
    if (selectedTrade !== 'all' && job.trackId !== selectedTrade) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match = job.title.toLowerCase().includes(q) || 
                    job.employer.toLowerCase().includes(q) || 
                    job.description.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  const getApplicationForJob = (jobId: string) => {
    return applications.find(a => a.jobId === jobId);
  };

  const hasMatchingCert = (trackId: string) => {
    return earnedCertificates.some(c => c.trackId === trackId);
  };

  const handleWhatsAppRecruiter = (job: JobOpportunity) => {
    const cert = earnedCertificates.find(c => c.trackId === job.trackId);
    const msg = encodeURIComponent(
      `Hello ${job.employer} Hiring Team! My name is ${workerName}. I am interested in applying for the ${job.title} role in ${job.location}.\n` +
      `I am certified on FundiSkill: ${cert ? cert.trackTitle + ' (ID: ' + cert.id + ')' : 'Completed Vocational Training'}.\n` +
      `Can we discuss interview scheduling? Thank you!`
    );
    window.open(`https://api.whatsapp.com/send?phone=${job.whatsappContact}&text=${msg}`, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner with Post Job Action */}
      <div className="bg-slate-900 text-white p-5 rounded-3xl border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-md">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-wider font-bold text-amber-400">
              DIRECT INDUSTRY PLACEMENTS
            </span>
            <span className="text-slate-500">·</span>
            <span className="text-xs text-slate-300">Zero Middleman Fees</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight mt-1">
            Jobs for Certified Technicians
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-xl leading-relaxed">
            Employers hire directly through FundiSkill with transparent wages and verified skills passports. 1-tap apply or chat directly with the recruiter on WhatsApp.
          </p>
        </div>

        <button
          onClick={onOpenPostJob}
          className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors shrink-0 shadow-sm"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Employer? Post a Job</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-2.5">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search job title, employer, or skill..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-slate-900"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={selectedCity}
            onChange={(e) => setSelectedCity(e.target.value)}
            className="w-full sm:w-auto px-3 py-2 rounded-xl border border-slate-200 text-xs bg-white text-slate-700 font-medium focus:outline-none"
          >
            <option value="all">All Cities</option>
            <option value="nairobi">Nairobi, Kenya</option>
            <option value="kigali">Kigali, Rwanda</option>
            <option value="bangalore">Bangalore, India</option>
            <option value="nakuru">Nakuru, Kenya</option>
          </select>

          <select
            value={selectedTrade}
            onChange={(e) => setSelectedTrade(e.target.value)}
            className="w-full sm:w-auto px-3 py-2 rounded-xl border border-slate-200 text-xs bg-white text-slate-700 font-medium focus:outline-none"
          >
            <option value="all">All Trades</option>
            <option value="solar_pv_tech">Solar & Mini-Grids</option>
            <option value="ev_boda_mechanic">EV & Boda-Boda</option>
            <option value="health_cold_chain">Healthcare Cold-Chain</option>
            <option value="smart_irrigation_tech">Solar Irrigation</option>
          </select>
        </div>
      </div>

      {/* Job Cards List */}
      <div className="space-y-4">
        {filteredJobs.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 text-slate-500 text-xs">
            No job openings match your filter criteria. Try selecting "All Trades" or "All Cities".
          </div>
        ) : (
          filteredJobs.map((job) => {
            const application = getApplicationForJob(job.id);
            const isMatch = hasMatchingCert(job.trackId);

            return (
              <div
                key={job.id}
                className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-sm space-y-3 transition-all hover:border-slate-300"
              >
                {/* Header: Title, Employer, Wage */}
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  <div>
                    {/* Unboxed Metadata Line with · Separator */}
                    <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500 mb-1">
                      <span className="font-semibold text-slate-900 flex items-center gap-1">
                        {job.employer}
                        {job.verifiedEmployer && <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        {job.location}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{job.jobType}</span>
                    </div>

                    <h3 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                      {job.title}
                    </h3>
                  </div>

                  {/* Wage Display */}
                  <div className="text-left sm:text-right shrink-0">
                    <div className="text-base font-extrabold font-mono text-slate-900">
                      {job.monthlyWage}
                    </div>
                    {job.dailyRate && (
                      <div className="text-[11px] text-slate-500 font-mono">
                        or {job.dailyRate}
                      </div>
                    )}
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {job.description}
                </p>

                {/* Stipends & Perks Chips */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {job.stipendPerks.map((perk, pIdx) => (
                    <span key={pIdx} className="bg-slate-100 text-slate-700 text-[11px] px-2.5 py-0.5 rounded-md font-medium">
                      + {perk}
                    </span>
                  ))}
                </div>

                {/* Match indicator & Credential Requirement */}
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-500 font-medium">Required:</span>
                    <span className="font-semibold text-slate-800">{job.requiredCertificate}</span>
                  </div>

                  {isMatch ? (
                    <span className="text-emerald-700 font-bold flex items-center gap-1 text-[11px]">
                      <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                      100% Certified Match
                    </span>
                  ) : (
                    <span className="text-amber-800 text-[11px] font-medium">
                      Complete track to boost placement priority
                    </span>
                  )}
                </div>

                {/* Actions: Quick Apply or WhatsApp Recruiter */}
                <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-2">
                  <div className="text-xs text-slate-400">
                    {job.vacancies} openings · Posted {job.postedDate}
                  </div>

                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <button
                      onClick={() => handleWhatsAppRecruiter(job)}
                      className="flex-1 sm:flex-initial px-3.5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>WhatsApp Recruiter</span>
                    </button>

                    <button
                      onClick={() => onApplyJob(job)}
                      disabled={!!application}
                      className={`flex-1 sm:flex-initial px-4 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors ${
                        application
                          ? 'bg-slate-100 text-slate-500 border border-slate-300 cursor-default'
                          : 'bg-slate-900 hover:bg-slate-800 text-white'
                      }`}
                    >
                      {application ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Status: {application.status}</span>
                        </>
                      ) : (
                        <>
                          <span>1-Tap Apply</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
