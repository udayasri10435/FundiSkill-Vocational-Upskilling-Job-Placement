import React from 'react';
import { LanguageCode } from '../types';
import { TRANSLATIONS } from '../data/vocationalData';
import { 
  Wifi, 
  WifiOff, 
  Globe, 
  Zap, 
  Layers
} from 'lucide-react';

interface HeaderProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  lang: LanguageCode;
  onLangChange: (lang: LanguageCode) => void;
  lowDataMode: boolean;
  onToggleLowData: () => void;
  isOnline: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onTabChange,
  lang,
  onLangChange,
  lowDataMode,
  onToggleLowData,
  isOnline,
}) => {
  const t = TRANSLATIONS[lang] || TRANSLATIONS.en;

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark as required by Top Bar Contract */}
        <button
          onClick={() => onTabChange('tracks')}
          className="text-left group flex items-center gap-2"
        >
          <div className="w-8 h-8 rounded-lg bg-amber-500 flex items-center justify-center text-slate-950 font-black text-base shadow-xs">
            F
          </div>
          <div>
            <span className="text-lg font-extrabold tracking-tight text-slate-950 group-hover:text-amber-800 transition-colors">
              FundiSkill
            </span>
          </div>
        </button>

        {/* Zone 2: 4-5 clean text navigation links (hidden on mobile, handled by bottom nav) */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-600">
          <button
            onClick={() => onTabChange('tracks')}
            className={`hover:text-slate-950 transition-colors whitespace-nowrap ${
              currentTab === 'tracks' ? 'text-slate-950 font-bold border-b-2 border-slate-900 pb-0.5' : ''
            }`}
          >
            {t.learn}
          </button>

          <button
            onClick={() => onTabChange('simulators')}
            className={`hover:text-slate-950 transition-colors whitespace-nowrap ${
              currentTab === 'simulators' ? 'text-slate-950 font-bold border-b-2 border-slate-900 pb-0.5' : ''
            }`}
          >
            {t.simulators}
          </button>

          <button
            onClick={() => onTabChange('certificates')}
            className={`hover:text-slate-950 transition-colors whitespace-nowrap ${
              currentTab === 'certificates' ? 'text-slate-950 font-bold border-b-2 border-slate-900 pb-0.5' : ''
            }`}
          >
            {t.certificates}
          </button>

          <button
            onClick={() => onTabChange('jobs')}
            className={`hover:text-slate-950 transition-colors whitespace-nowrap ${
              currentTab === 'jobs' ? 'text-slate-950 font-bold border-b-2 border-slate-900 pb-0.5' : ''
            }`}
          >
            {t.jobs}
          </button>

          <button
            onClick={() => onTabChange('passport')}
            className={`hover:text-slate-950 transition-colors whitespace-nowrap ${
              currentTab === 'passport' ? 'text-slate-950 font-bold border-b-2 border-slate-900 pb-0.5' : ''
            }`}
          >
            {t.passport}
          </button>
        </nav>

        {/* Zone 3: 1-2 primary controls (Low-Data Switch & Language Picker) */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Low-Data Toggle Button */}
          <button
            onClick={onToggleLowData}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
              lowDataMode
                ? 'bg-amber-100 text-amber-950 border border-amber-300 font-bold'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
            title="Toggle between Ultra Low-Data (2G/3G) vector schematics and full media"
          >
            <Zap className={`w-3.5 h-3.5 ${lowDataMode ? 'text-amber-700 fill-amber-700' : 'text-slate-500'}`} />
            <span className="hidden sm:inline">{lowDataMode ? '2G Lite (94% Saved)' : 'Lite Mode'}</span>
            <span className="sm:hidden">{lowDataMode ? 'Lite' : 'Std'}</span>
          </button>

          {/* Language Selector */}
          <div className="relative flex items-center">
            <Globe className="w-3.5 h-3.5 absolute left-2 text-slate-500 pointer-events-none" />
            <select
              value={lang}
              onChange={(e) => onLangChange(e.target.value as LanguageCode)}
              className="pl-7 pr-2 py-1.5 rounded-lg border border-slate-300 text-xs bg-white text-slate-800 font-medium focus:outline-none focus:ring-1 focus:ring-slate-900 cursor-pointer"
            >
              <option value="en">English</option>
              <option value="sw">Kiswahili</option>
              <option value="hi">हिंदी (Hindi)</option>
              <option value="fr">Français</option>
              <option value="id">Bahasa ID</option>
              <option value="es">Español</option>
            </select>
          </div>

          {/* Online/Offline status indicator */}
          <div
            className={`w-2.5 h-2.5 rounded-full ${
              isOnline ? 'bg-emerald-500 ring-2 ring-emerald-200' : 'bg-amber-500 ring-2 ring-amber-200'
            }`}
            title={isOnline ? 'Connected (Online)' : 'Offline Local Storage Mode'}
          />
        </div>
      </div>
    </header>
  );
};
