import React, { useState, useEffect } from 'react';
import { 
  VocationalTrack, 
  CourseModule, 
  CertificateRecord, 
  JobOpportunity, 
  JobApplication, 
  UserWorkerProfile, 
  LanguageCode 
} from './types';
import { 
  VOCATIONAL_TRACKS, 
  INITIAL_JOBS, 
  TRANSLATIONS 
} from './data/vocationalData';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { CourseCatalog } from './components/CourseCatalog';
import { LessonViewer } from './components/LessonViewer';
import { SolarTroubleshooter } from './components/simulators/SolarTroubleshooter';
import { EVMotorDiagnostic } from './components/simulators/EVMotorDiagnostic';
import { ColdChainSimulator } from './components/simulators/ColdChainSimulator';
import { CertificateCard } from './components/CertificateCard';
import { VerificationPortal } from './components/VerificationPortal';
import { JobBoard } from './components/JobBoard';
import { WorkerPassport } from './components/WorkerPassport';
import { ExamModal } from './components/ExamModal';
import { PostJobModal } from './components/PostJobModal';
import { 
  Zap, 
  Cpu, 
  Award, 
  Briefcase, 
  RefreshCw, 
  CheckCircle2, 
  Sparkles,
  ChevronRight,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';

const INITIAL_PROFILE: UserWorkerProfile = {
  name: 'Grace Mwangi',
  phone: '+254 712 345 678',
  city: 'Nairobi',
  country: 'Kenya',
  tradeSpecialty: 'Solar PV & Off-Grid Mini-Grids',
  lowDataMode: true,
  downloadedTracks: ['solar_pv_tech'],
  completedModules: ['mod_solar_1', 'mod_solar_2'],
  completedSimulators: ['solar_troubleshooter'],
  earnedCertificates: [
    {
      id: 'FS-KE-849201',
      trackId: 'solar_pv_tech',
      trackTitle: 'Certified Solar PV & Distributed Mini-Grid Installer (Level 3)',
      studentName: 'Grace Mwangi',
      issueDate: 'August 2026',
      theoryScore: 94,
      practicalScore: 98,
      safetyRubricScore: 100,
      verifierOrganization: 'Vocational Technical Training Consortium (TVET)',
      qrCodeSeed: 'https://fundiskill.org/verify/FS-KE-849201',
      blockchainHash: '0x8f2a93c71e0b5d4a6e8f1c3b5d7e9a1c2e4f6a8b',
    }
  ],
  offlineSyncQueue: [],
  dataSavedMb: 42.6,
  toolHoursLogged: 24,
};

export default function App() {
  // Navigation & Language
  const [currentTab, setCurrentTab] = useState<string>('tracks');
  const [lang, setLang] = useState<LanguageCode>('en');
  const [lowDataMode, setLowDataMode] = useState<boolean>(true);
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Lesson & Simulator Viewing
  const [activeModule, setActiveModule] = useState<CourseModule | null>(null);
  const [activeTrack, setActiveTrack] = useState<VocationalTrack | null>(null);
  const [activeSimulatorId, setActiveSimulatorId] = useState<string>('solar_troubleshooter');

  // Modals
  const [isExamModalOpen, setIsExamModalOpen] = useState<boolean>(false);
  const [examTrack, setExamTrack] = useState<VocationalTrack | null>(null);
  const [isVerifyModalOpen, setIsVerifyModalOpen] = useState<boolean>(false);
  const [verifyCertId, setVerifyCertId] = useState<string>('FS-KE-849201');
  const [isPostJobModalOpen, setIsPostJobModalOpen] = useState<boolean>(false);

  // Data Collections with LocalStorage hydration
  const [profile, setProfile] = useState<UserWorkerProfile>(() => {
    try {
      const saved = localStorage.getItem('fundiskill_profile');
      return saved ? JSON.parse(saved) : INITIAL_PROFILE;
    } catch {
      return INITIAL_PROFILE;
    }
  });

  const [jobs, setJobs] = useState<JobOpportunity[]>(() => {
    try {
      const saved = localStorage.getItem('fundiskill_jobs');
      return saved ? JSON.parse(saved) : INITIAL_JOBS;
    } catch {
      return INITIAL_JOBS;
    }
  });

  const [applications, setApplications] = useState<JobApplication[]>(() => {
    try {
      const saved = localStorage.getItem('fundiskill_applications');
      return saved ? JSON.parse(saved) : [
        {
          id: 'app_1',
          jobId: 'job_sun_01',
          applicantName: 'Grace Mwangi',
          phone: '+254 712 345 678',
          whatsapp: '+254 712 345 678',
          appliedDate: 'Yesterday',
          status: 'Verification in Review',
          attachedCertificates: ['FS-KE-849201'],
        }
      ];
    } catch {
      return [];
    }
  });

  const [syncToast, setSyncToast] = useState<string | null>(null);

  // Persist state
  useEffect(() => {
    try {
      localStorage.setItem('fundiskill_profile', JSON.stringify(profile));
    } catch {}
  }, [profile]);

  useEffect(() => {
    try {
      localStorage.setItem('fundiskill_jobs', JSON.stringify(jobs));
    } catch {}
  }, [jobs]);

  useEffect(() => {
    try {
      localStorage.setItem('fundiskill_applications', JSON.stringify(applications));
    } catch {}
  }, [applications]);

  // Online / Offline window listeners
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Sync Queue simulation
  const handleManualSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setProfile(prev => ({
        ...prev,
        offlineSyncQueue: [],
        dataSavedMb: prev.dataSavedMb + 1.8,
      }));
      setIsSyncing(false);
      setSyncToast('Offline queue synced successfully with national TVET registry!');
      setTimeout(() => setSyncToast(null), 3500);
    }, 1200);
  };

  // Toggle Low-Data
  const handleToggleLowData = () => {
    const nextVal = !lowDataMode;
    setLowDataMode(nextVal);
    setProfile(prev => ({
      ...prev,
      lowDataMode: nextVal,
      dataSavedMb: nextVal ? prev.dataSavedMb + 4.2 : prev.dataSavedMb,
    }));
  };

  // Complete module
  const handleCompleteModule = (moduleId: string) => {
    setProfile(prev => {
      const already = prev.completedModules.includes(moduleId);
      if (already) return prev;
      return {
        ...prev,
        completedModules: [...prev.completedModules, moduleId],
        toolHoursLogged: prev.toolHoursLogged + 2,
        dataSavedMb: prev.dataSavedMb + 0.8,
        offlineSyncQueue: [
          ...prev.offlineSyncQueue,
          {
            type: 'module_complete',
            payload: { moduleId },
            timestamp: new Date().toISOString(),
          }
        ]
      };
    });
    setSyncToast('Module marked completed and saved to your skill passport!');
    setTimeout(() => setSyncToast(null), 3000);
  };

  // Download track for offline
  const handleDownloadTrack = (trackId: string) => {
    setProfile(prev => {
      const isDown = prev.downloadedTracks.includes(trackId);
      const updated = isDown
        ? prev.downloadedTracks.filter(id => id !== trackId)
        : [...prev.downloadedTracks, trackId];
      return {
        ...prev,
        downloadedTracks: updated,
        dataSavedMb: prev.dataSavedMb + 0.6,
      };
    });
    setSyncToast('Track downloaded for zero-data offline learning!');
    setTimeout(() => setSyncToast(null), 3000);
  };

  // Lab completion
  const handleLabComplete = (score: number) => {
    setProfile(prev => ({
      ...prev,
      completedSimulators: [...new Set([...prev.completedSimulators, activeSimulatorId])],
      toolHoursLogged: prev.toolHoursLogged + 3,
      offlineSyncQueue: [
        ...prev.offlineSyncQueue,
        {
          type: 'simulator_score',
          payload: { simulatorId: activeSimulatorId, score },
          timestamp: new Date().toISOString(),
        }
      ]
    }));
    setSyncToast(`Practical Lab complete (${score}%). Score recorded!`);
    setTimeout(() => setSyncToast(null), 3500);
  };

  // Pass Exam & Issue Certificate
  const handlePassExam = (newCert: CertificateRecord) => {
    setProfile(prev => ({
      ...prev,
      earnedCertificates: [newCert, ...prev.earnedCertificates],
      toolHoursLogged: prev.toolHoursLogged + 4,
    }));
    setCurrentTab('certificates');
    setSyncToast(`Congratulations! Certified in ${newCert.trackTitle}`);
    setTimeout(() => setSyncToast(null), 4000);
  };

  // 1-Tap Job Apply
  const handleApplyJob = (job: JobOpportunity) => {
    const existing = applications.find(a => a.jobId === job.id);
    if (existing) return;

    const newApp: JobApplication = {
      id: `app_${Date.now()}`,
      jobId: job.id,
      applicantName: profile.name,
      phone: profile.phone,
      whatsapp: profile.phone,
      appliedDate: 'Just now',
      status: 'Submitted',
      attachedCertificates: profile.earnedCertificates.map(c => c.id),
    };

    setApplications(prev => [newApp, ...prev]);
    setSyncToast(`Application submitted to ${job.employer} with your verified passport!`);
    setTimeout(() => setSyncToast(null), 3500);
  };

  // Add Employer Job
  const handleAddJob = (newJob: JobOpportunity) => {
    setJobs(prev => [newJob, ...prev]);
    setSyncToast('New vocational job posting published!');
    setTimeout(() => setSyncToast(null), 3000);
  };

  const t = TRANSLATIONS[lang] || TRANSLATIONS.en;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Strict 3-zone Header */}
      <Header
        currentTab={currentTab}
        onTabChange={(tab) => {
          setActiveModule(null);
          setCurrentTab(tab);
        }}
        lang={lang}
        onLangChange={setLang}
        lowDataMode={lowDataMode}
        onToggleLowData={handleToggleLowData}
        isOnline={isOnline}
      />

      {/* Low-Data Savings & Offline Telemetry Banner */}
      <div className="bg-amber-500/10 border-b border-amber-500/20 px-4 py-2 text-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-amber-950 font-medium">
            <Zap className="w-3.5 h-3.5 text-amber-600 fill-amber-600 shrink-0" />
            <span>
              {lowDataMode ? '⚡ 2G/3G Low-Data Mode Active' : 'Standard Bandwidth Mode'}
            </span>
            <span className="hidden sm:inline text-slate-400">·</span>
            <span className="hidden sm:inline text-slate-600">
              {profile.dataSavedMb.toFixed(1)} MB saved using lightweight vector schematics
            </span>
          </div>

          <div className="flex items-center gap-3 text-[11px] font-mono">
            {profile.offlineSyncQueue.length > 0 ? (
              <button
                onClick={handleManualSync}
                className="text-amber-900 underline font-semibold flex items-center gap-1 hover:text-amber-950"
              >
                <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>{profile.offlineSyncQueue.length} records pending sync</span>
              </button>
            ) : (
              <span className="text-emerald-700 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                Offline cache synced
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Sync Toast Feedback */}
      {syncToast && (
        <div className="fixed top-20 right-4 z-50 bg-slate-950 text-white px-4 py-3 rounded-2xl shadow-xl border border-slate-800 text-xs font-semibold flex items-center gap-2.5 animate-in slide-in-from-top duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{syncToast}</span>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 pb-24 md:pb-12">
        {/* VIEW 1: VOCATIONAL TRACKS / LESSON VIEWER */}
        {currentTab === 'tracks' && (
          <div>
            {activeModule && activeTrack ? (
              <LessonViewer
                module={activeModule}
                simulatorId={activeTrack.simulatorId}
                isCompleted={profile.completedModules.includes(activeModule.id)}
                onComplete={() => handleCompleteModule(activeModule.id)}
                onBack={() => setActiveModule(null)}
                onLaunchSimulator={(simId) => {
                  setActiveSimulatorId(simId);
                  setCurrentTab('simulators');
                }}
              />
            ) : (
              <div className="space-y-6">
                {/* Hero section */}
                <div className="bg-slate-900 text-white p-6 sm:p-8 rounded-3xl border border-slate-800 relative overflow-hidden shadow-lg">
                  <div className="max-w-2xl space-y-2 relative z-10">
                    <div className="flex items-center gap-2 text-xs font-bold text-amber-400 tracking-wider uppercase">
                      <span>Certified Vocational Pathways</span>
                      <span>·</span>
                      <span>Emerging Market Trades</span>
                    </div>
                    <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white leading-tight">
                      Master High-Demand Green Trades with Zero-Data Labs
                    </h1>
                    <p className="text-xs sm:text-sm text-slate-300 leading-relaxed pt-1">
                      Designed for spotty 2G/3G networks across East Africa, West Africa, and South Asia. Learn hands-on diagnostics, earn tamper-proof TVET micro-credentials, and get placed with verified employers.
                    </p>

                    {/* Quick Stat Bar */}
                    <div className="flex flex-wrap gap-4 pt-3 text-xs font-mono text-slate-300">
                      <div>
                        <span className="text-amber-400 font-bold">KES 48,000+</span> avg entry wage
                      </div>
                      <span className="text-slate-600">·</span>
                      <div>
                        <span className="text-emerald-400 font-bold">100%</span> mobile-first
                      </div>
                      <span className="text-slate-600">·</span>
                      <div>
                        <span className="text-sky-400 font-bold">&lt; 200KB</span> offline pack size
                      </div>
                    </div>
                  </div>
                </div>

                {/* Course Catalog */}
                <CourseCatalog
                  tracks={VOCATIONAL_TRACKS}
                  completedModules={profile.completedModules}
                  downloadedTracks={profile.downloadedTracks}
                  onSelectModule={(mod, track) => {
                    setActiveModule(mod);
                    setActiveTrack(track);
                  }}
                  onLaunchSimulator={(simId) => {
                    setActiveSimulatorId(simId);
                    setCurrentTab('simulators');
                  }}
                  onDownloadTrack={handleDownloadTrack}
                  onTakeExam={(track) => {
                    setExamTrack(track);
                    setIsExamModalOpen(true);
                  }}
                />
              </div>
            )}
          </div>
        )}

        {/* VIEW 2: PRACTICAL HARDWARE LABS & SIMULATORS */}
        {currentTab === 'simulators' && (
          <div className="space-y-6">
            {/* Lab Switcher Segmented Control */}
            <div className="flex items-center gap-1.5 p-1 bg-slate-200/80 rounded-xl overflow-x-auto no-scrollbar text-xs">
              <button
                onClick={() => setActiveSimulatorId('solar_troubleshooter')}
                className={`px-3.5 py-1.5 font-medium rounded-lg whitespace-nowrap transition-colors ${
                  activeSimulatorId === 'solar_troubleshooter'
                    ? 'bg-white text-slate-900 shadow-sm font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Solar Inverter & Wiring Multimeter Lab
              </button>

              <button
                onClick={() => setActiveSimulatorId('ev_motor_diagnostic')}
                className={`px-3.5 py-1.5 font-medium rounded-lg whitespace-nowrap transition-colors ${
                  activeSimulatorId === 'ev_motor_diagnostic'
                    ? 'bg-white text-slate-900 shadow-sm font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Electric 2-Wheeler (Boda) Battery & Motor Lab
              </button>

              <button
                onClick={() => setActiveSimulatorId('cold_chain_simulator')}
                className={`px-3.5 py-1.5 font-medium rounded-lg whitespace-nowrap transition-colors ${
                  activeSimulatorId === 'cold_chain_simulator'
                    ? 'bg-white text-slate-900 shadow-sm font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Healthcare Vaccine Cold-Chain Refrigerator Lab
              </button>
            </div>

            {/* Active Simulator Render */}
            {activeSimulatorId === 'solar_troubleshooter' && (
              <SolarTroubleshooter
                lowDataMode={lowDataMode}
                onCompleteLab={handleLabComplete}
              />
            )}

            {activeSimulatorId === 'ev_motor_diagnostic' && (
              <EVMotorDiagnostic
                lowDataMode={lowDataMode}
                onCompleteLab={handleLabComplete}
              />
            )}

            {activeSimulatorId === 'cold_chain_simulator' && (
              <ColdChainSimulator
                lowDataMode={lowDataMode}
                onCompleteLab={handleLabComplete}
              />
            )}
          </div>
        )}

        {/* VIEW 3: TAMPER-PROOF CERTIFICATES & PUBLIC VERIFICATION */}
        {currentTab === 'certificates' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                  My Verified Micro-Credentials
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Cryptographically registered TVET certificates ready for employer verification or WhatsApp sharing.
                </p>
              </div>

              <button
                onClick={() => setIsVerifyModalOpen(true)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Open Public Registry Portal</span>
              </button>
            </div>

            {profile.earnedCertificates.length === 0 ? (
              <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 shadow-xs max-w-xl mx-auto space-y-3">
                <Award className="w-12 h-12 text-slate-300 mx-auto" />
                <h3 className="text-base font-bold text-slate-900">No Certificates Earned Yet</h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Complete the modules in a vocational track and take the certification exam to earn your tamper-proof license card.
                </p>
                <button
                  onClick={() => setCurrentTab('tracks')}
                  className="px-4 py-2 bg-slate-900 text-white text-xs font-bold rounded-xl"
                >
                  Browse Vocational Tracks
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                {profile.earnedCertificates.map((cert) => (
                  <CertificateCard
                    key={cert.id}
                    certificate={cert}
                    onVerifyModalOpen={(id) => {
                      setVerifyCertId(id);
                      setIsVerifyModalOpen(true);
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* VIEW 4: JOB PLACEMENTS & EMPLOYER HIRING PIPELINE */}
        {currentTab === 'jobs' && (
          <JobBoard
            jobs={jobs}
            applications={applications}
            earnedCertificates={profile.earnedCertificates}
            onApplyJob={handleApplyJob}
            onOpenPostJob={() => setIsPostJobModalOpen(true)}
            workerName={profile.name}
          />
        )}

        {/* VIEW 5: WORKER PASSPORT & OFFLINE ENGINE */}
        {currentTab === 'passport' && (
          <WorkerPassport
            profile={profile}
            onUpdateProfile={(updated) => setProfile(prev => ({ ...prev, ...updated }))}
            onManualSync={handleManualSync}
            isSyncing={isSyncing}
          />
        )}
      </main>

      {/* Ergonomic Mobile Bottom Nav (hidden on desktop) */}
      <BottomNav
        currentTab={currentTab}
        onTabChange={(tab) => {
          setActiveModule(null);
          setCurrentTab(tab);
        }}
        earnedCertCount={profile.earnedCertificates.length}
      />

      {/* Certification Exam Modal */}
      <ExamModal
        track={examTrack}
        isOpen={isExamModalOpen}
        onClose={() => setIsExamModalOpen(false)}
        onPassExam={handlePassExam}
        studentName={profile.name}
      />

      {/* Public Registry Verification Modal */}
      <VerificationPortal
        isOpen={isVerifyModalOpen}
        onClose={() => setIsVerifyModalOpen(false)}
        certificates={profile.earnedCertificates}
        initialCertId={verifyCertId}
      />

      {/* Post a Job Modal for Employers */}
      <PostJobModal
        isOpen={isPostJobModalOpen}
        onClose={() => setIsPostJobModalOpen(false)}
        onAddJob={handleAddJob}
      />
    </div>
  );
}
