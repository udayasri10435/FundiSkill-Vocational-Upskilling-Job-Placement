export type LanguageCode = 'en' | 'sw' | 'hi' | 'fr' | 'id' | 'es';

export interface VocationalTrack {
  id: string;
  title: string;
  category: 'clean_energy' | 'e_mobility' | 'health_tech' | 'agri_water';
  marketDemand: 'Ultra High' | 'High' | 'Rising';
  regionFocus: string[]; // e.g., ["East Africa", "South Asia", "West Africa"]
  avgEntryWage: string; // e.g., "$280 - $450 / month"
  practicalHours: number;
  dataPackSizeKb: number; // Low-data download size (e.g. 185 KB)
  iconName: string;
  description: string;
  modules: CourseModule[];
  simulatorId: string;
  certificateTitle: string;
}

export interface CourseModule {
  id: string;
  trackId: string;
  title: string;
  readTimeMin: number;
  audioDurationMin: number;
  keySkills: string[];
  audioScript: string;
  summary: string;
  svgSchematicType: 'solar_circuit' | 'ev_bldc' | 'cold_chain' | 'pump_schematic';
  checklist: string[];
  diagnosticQuiz: QuizQuestion[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  safetyCritical?: boolean;
}

export interface CertificateRecord {
  id: string; // e.g. "FS-KE-849201"
  trackId: string;
  trackTitle: string;
  studentName: string;
  issueDate: string;
  theoryScore: number;
  practicalScore: number;
  safetyRubricScore: number;
  verifierOrganization: string;
  qrCodeSeed: string;
  blockchainHash: string;
}

export interface JobOpportunity {
  id: string;
  title: string;
  employer: string;
  verifiedEmployer: boolean;
  location: string;
  city: string;
  country: string;
  trackId: string;
  monthlyWage: string;
  dailyRate?: string;
  stipendPerks: string[]; // e.g., ["Free Daily Lunch", "Toolkit Provided", "Health Insurance"]
  jobType: 'Full-time' | 'Apprenticeship' | 'Contract';
  vacancies: number;
  postedDate: string;
  whatsappContact: string;
  smsNumber: string;
  requiredCertificate: string;
  description: string;
}

export interface JobApplication {
  id: string;
  jobId: string;
  applicantName: string;
  phone: string;
  whatsapp: string;
  appliedDate: string;
  status: 'Submitted' | 'Verification in Review' | 'Technical Interview' | 'Hired';
  attachedCertificates: string[];
}

export interface UserWorkerProfile {
  name: string;
  phone: string;
  city: string;
  country: string;
  tradeSpecialty: string;
  lowDataMode: boolean;
  downloadedTracks: string[]; // track IDs downloaded offline
  completedModules: string[]; // module IDs completed
  completedSimulators: string[];
  earnedCertificates: CertificateRecord[];
  offlineSyncQueue: {
    type: 'module_complete' | 'simulator_score' | 'job_apply';
    payload: any;
    timestamp: string;
  }[];
  dataSavedMb: number;
  toolHoursLogged: number;
}
